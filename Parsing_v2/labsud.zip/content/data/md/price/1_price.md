<table>
<thead>
<tr>
<td>
<p align="center" class="western"><strong>Вид экспертизы</strong></p>
</td>
<td>
<p align="center" class="western" lang="en-US"><strong>Минимальная стоимость досудебного исследования, руб.</strong></p>
</td>
<td>
<p align="center" class="western"><strong>Стоимость судебной экспертизы, руб.</strong></p>
</td>
<td>
<p align="center" class="western" lang="en-US"><strong>Минимальный срок проведения, дн</strong></p>
</td>
</tr>
</thead>
<tbody>
<tr valign="bottom">
<td class="td-title" colspan="4" valign="bottom">
<div class="td-div-title">
<p class="western"><strong><a href="uslugi-ekspertizyi/tovarnaya-ekspertiza/" style="color: inherit;">Товарная экспертиза</a></strong></p>
<a class="header_link_franshiza" data-fancybox="" href="#order_call">Заказать</a>
</div>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU"><a href="/uslugi-ekspertizyi/tovarnaya-ekspertiza/ekspertiza-telefonov-i-planshetov/" target="_blank"><strong>Экспертиза сотовых телефонов и электротехники</strong></a>, бытового оборудования и бытовой техники</span></p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU">&lt; 20 000 руб.</span></p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU">&gt; 20 001 руб.</span></p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU">Услуги авторизованного сервисного центра </span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">10 000</p>
<p align="center" class="western">12 000</p>
<p align="center" class="western">–</p>
</td>
<td valign="bottom" width="136">
<p align="center" class="western">16 000</p>
<p align="center" class="western">20 000</p>
<p align="center" class="western">1 000</p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU"><a href="/uslugi-ekspertizyi/tovarnaya-ekspertiza/ekspertiza-mashin-i-mexanizmov/" target="_blank"><strong>Экспертиза машин и механизмов</strong></a>, технологического оборудования, ТС, узлов и агрегатов </span></p>
<p align="right" class="western">1 дефекта 1-ой ед.</p>
<p align="right" class="western">до 3-х дефектов до 3-х ед.</p>
<p align="right" class="western">4-5 дефектов 4-5 ед. </p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">15 000</span></p>
<p align="center" class="western">10 000</p>
<p align="center" class="western">8 000</p>
</td>
<td valign="bottom" width="136">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">25 000</span></p>
<p align="center" class="western">15 000</p>
<p align="center" class="western">12 000</p>
</td>
<td width="62">
<p align="center" class="western"> </p>
<p align="center" class="western">5-10</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western" lang="en-US"><span lang="ru-RU">Экспертиза оборудования, ТС, пр. имущества в силу частичной или полной гибели для списания</span></p>
<p align="right" class="western">1-3 ед.</p>
<p align="right" class="western">4-5 ед.</p>
<p align="right" class="western">6-10 ед.</p>
<p align="right" class="western">10-30 ед.</p>
<p align="right" class="western">30-50 ед. </p>
</td>
<td width="118">
<p align="center" class="western">3 000</p>
<p align="center" class="western">2 500</p>
<p align="center" class="western">2 000</p>
<p align="center" class="western">1 750</p>
<p align="center" class="western">1 500</p>
</td>
<td width="136">
<p align="center" class="western">6 000</p>
<p align="center" class="western">5 000</p>
<p align="center" class="western">4 000</p>
<p align="center" class="western">3 500</p>
<p align="center" class="western">3 000</p>
</td>
<td width="62">
<p align="center" class="western">5-10</p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td class="td-title" colspan="4" valign="bottom">
<div class="td-div-title">
<p class="western"><strong><a href="uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/" style="color: inherit;">Строительно-техническая экспертиза</a></strong></p>
<a class="header_link_franshiza" data-fancybox="" href="#order_call">Заказать</a>
</div>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western" lang="en-US"><span lang="ru-RU"><a href="/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/ekspertiza-kachestva-stroitelstva/" target="_blank"><strong>Экспертиза качества отделки и строительно-монтажных работ</strong></a>, </span></p>
<p class="western" lang="en-US"><span lang="ru-RU"><em>*доп. составление сметы на устранение дефектов, % от стоимости обследования</em></span></p>
<p class="western" lang="en-US"><span lang="ru-RU"><em>*доп. составление акта обследования без обмерных работ (не &lt;1 ч)/с работами (не &lt;2 ч)</em></span></p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU"><em><u>жилые помещения</u></em> площадью до 50 кв.м.</span></p>
<p align="right" class="western">51–100 кв.м.</p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU">101–300 кв.м. </span></p>
<p align="right" class="western">&gt;300 кв.м. </p>
<p align="center" class="western"> </p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU"><em><u>нежилые помещения</u></em> до 100 кв.м.</span></p>
<p align="right" class="western">101–300 кв.м.</p>
<p align="right" class="western">300–500 кв.м.</p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU">500–1000 кв.м.</span></p>
<p align="right" class="western">&gt;1000 кв.м.</p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">20%</span></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">2 500 руб./час</span></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">8 000*</span></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">12 000*</span></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">19 000</span></p>
<p align="center" class="western">25 000</p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">15 000</span></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">20 000</span></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">40 000</span></p>
<p align="center" class="western">50 000</p>
<p align="center" class="western"> </p>
<p align="center" class="western">60 000</p>
<p align="center" class="western"> </p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">20%</span></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">2 500 руб./час</span></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">15 000*</span></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">18 000*</span></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">30 000</span></p>
<p align="center" class="western">35 000</p>
<p align="center" class="western"><br/></p>
<p align="center" class="western"><br/></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">22 000</span></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">28 000</span></p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">50 000</span></p>
<p align="center" class="western">60 000</p>
<p align="center" class="western"> </p>
<p align="center" class="western">80 000</p>
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western">5–10</p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU">Расчет инсоляционного режима земельного участка или жилого строения / помещения, руб. / объект</span></p>
</td>
<td width="118">
<p align="center" class="western">15 000</p>
</td>
<td width="136">
<p align="center" class="western">20 000</p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Экспертиза по определению объема фактически выполненных строительно-монтажных работ</p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">от 25 000 руб.</span></p>
<p align="center" class="western">предел рассчитывается по нормо-часам</p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">от 32 000 руб.</span></p>
<p align="center" class="western">предел рассчитывается по нормо-часам</p>
</td>
<td width="62">
<p align="center" class="western">5-15</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western" lang="en-US"><span lang="ru-RU"><a href="/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/ekspertiza-plastikovyix-okon-pvx/" target="_blank"><strong>Экспертиза оконных конструкций</strong></a>, дверных полотен </span></p>
<p class="western" lang="en-US"><span lang="ru-RU"><em>*доп. составление акта обследования без обмерных работ (не &lt;1 ч)/с работами (не &lt;2 ч)</em></span></p>
<p align="right" class="western">1 единица</p>
<p align="right" class="western">2-3 ед.</p>
<p align="right" class="western">4-5 ед.</p>
<p align="right" class="western">6-10 ед.</p>
</td>
<td width="118">
<p align="center" class="western">  </p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">5 000</span></p>
<p align="center" class="western">4 000</p>
<p align="center" class="western">3 000*</p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">2 500*</span></p>
</td>
<td width="136">
<p align="center" class="western">  </p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">9 000</span></p>
<p align="center" class="western">8 000</p>
<p align="center" class="western">5 000</p>
<p align="center" class="western" lang="en-US"><span lang="ru-RU">4 000</span></p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU">Экспертиза соответствия расположения строений на участке требованиям нормативных документов, руб./объект</span></p>
</td>
<td width="118">
<p align="center" class="western">20 000</p>
</td>
<td width="136">
<p align="center" class="western">25 000</p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Экспертиза по отнесению объекта к тому или иному типу (недвижимости, сооружению, стационарному / нестационарному объекту и т.п.)</p>
</td>
<td width="118">
<p align="center" class="western">20 000</p>
</td>
<td width="136">
<p align="center" class="western">25 000</p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr valign="bottom">
<td class="td-title" colspan="4" valign="bottom">
<div class="td-div-title">
<p class="western"><strong><a href="uslugi-ekspertizyi/buxgalterskaya-ekspertiza/" style="color: inherit;">Бухгалтерская экспертиза</a></strong></p>
<a class="header_link_franshiza" data-fancybox="" href="#order_call">Заказать</a>
</div>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Экспертиза бухгалтерской (финансовой отчетности)</p>
</td>
<td width="118">
<p class="western">30 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">1,2</p>
</td>
<td width="62">
<p align="center" class="western">7-15</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Экспертиза первичных документов</p>
</td>
<td width="118">
<p class="western">20 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">1,2</p>
</td>
<td width="62">
<p align="center" class="western">7-15</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Анализ финансово-хозяйственной деятельности </p>
</td>
<td width="118">
<p class="western">40 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">1,2</p>
</td>
<td width="62">
<p align="center" class="western">10-20</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU">Экспертиза преднамеренности и фиктивности банкротств</span></p>
</td>
<td width="118">
<p class="western">60 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">1,2</p>
</td>
<td width="62">
<p align="center" class="western">20-30</p>
</td>
</tr>
<tr valign="bottom">
<td class="td-title" colspan="4" valign="bottom">
<div class="td-div-title">
<p class="western"><strong><a href="uslugi-ekspertizyi/podcherkovedcheskaya-ekspertiza/" style="color: inherit;">Почерковедческая экспертиза</a></strong></p>
<a class="header_link_franshiza" data-fancybox="" href="#order_call">Заказать</a>
</div>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Экспертиза 1 подписи</p>
</td>
<td width="118">
<p class="western">12 000</p>
</td>
<td width="136">
<p align="center" class="western">15 000</p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Экспертиза 1 и более подписей</p>
</td>
<td valign="bottom" width="118">
<p class="western" lang="en-US"><span lang="ru-RU">первая подпись по тарифам, за каждую следующую подпись одного лица от 2 000</span></p>
</td>
<td width="136">
<p align="center" class="western">первая подпись по тарифам, за каждую следующую подпись одного лица от 3000</p>
</td>
<td width="62">
<p align="center" class="western">5-10</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Экспертиза 1 подписи; расшифровка ФИО</p>
</td>
<td valign="bottom" width="118">
<p class="western">18 000</p>
</td>
<td width="136">
<p align="center" class="western">20 000</p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Экспертиза 1 и более подписи; расшифровка ФИО</p>
</td>
<td valign="bottom" width="118">
<p class="western">первая подпись по тарифам, за каждую следующую подпись одного лица от 2 000</p>
</td>
<td width="136">
<p align="center" class="western">первая подпись по тарифам, за каждую следующую подпись одного лица от 3000</p>
</td>
<td width="62">
<p align="center" class="western">5-15</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Консультации при назначении технической экспертизы документов</p>
</td>
<td valign="bottom" width="118">
<p class="western">5 000</p>
</td>
<td width="136">
<p align="center" class="western">5 000</p>
</td>
<td width="62">
<p align="center" class="western">1</p>
</td>
</tr>
<tr valign="bottom">
<td class="td-title" colspan="4" valign="bottom">
<div class="td-div-title">
<p class="western"><strong><a href="uslugi-ekspertizyi/uslugi-oczenki/" style="color: inherit;">Оценочная экспертиза</a></strong></p>
<a class="header_link_franshiza" data-fancybox="" href="#order_call">Заказать</a>
</div>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><a href="/uslugi-oczenki/oczenka-kvartiryi/" target="_blank"><strong>Оценка квартир</strong></a></p>
</td>
<td width="118">
<p align="center" class="western">3 000</p>
</td>
<td width="136">
<p align="center" class="western">6 000</p>
</td>
<td width="62">
<p align="center" class="western">3</p>
</td>
</tr>
<tr valign="bottom">
<td class="td-title" colspan="4" valign="bottom">
<div class="td-div-title">
<p class="western"><strong><a href="osparivanie-kadastrovoj-stoimosti/" style="color: inherit;">Оспаривание кадастровой стоимости</a></strong></p>
<a class="header_link_franshiza" data-fancybox="" href="#order_call">Заказать</a>
</div>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western">Жилой недвижимости</p>
</td>
<td width="118">
<p align="center" class="western"></p>
</td>
<td width="136">
<p align="center" class="western">20 000</p>
</td>
<td width="62">
<p align="center" class="western"></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western">Земельных участков</p>
</td>
<td width="118">
<p align="center" class="western"></p>
</td>
<td width="136">
<p align="center" class="western">15 000</p>
</td>
<td width="62">
<p align="center" class="western"></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western">Оценка жилых домов с земельными участками</p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">9 000<span></span></span></p>
</td>
<td width="136">
<p align="center" class="western">15 000</p>
</td>
<td width="62">
<p align="center" class="western">5-10</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western" lang="en-US"><span lang="ru-RU">Оценка надворных построек (кухня, сарай, гараж, баня, бассейн, хозблок) и пр. улучшений земельного участка:</span></p>
<p align="right" class="western">ограждение, уборная, замощение территории</p>
<p align="right" class="western">надворные постройки</p>
</td>
<td width="118">
<p align="center" class="western">2 000</p>
<p align="center" class="western">3 000</p>
<p align="center" class="western"> </p>
</td>
<td width="136">
<p align="center" class="western">3 000</p>
<p align="center" class="western">4 000</p>
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western">3</p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western"><strong>Оценка нежилых помещений</strong></p>
</td>
<td valign="bottom" width="118">
<p class="western"> </p>
</td>
<td width="136">
<p align="center" class="western">1,2</p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western"><a href="/uslugi-oczenki/oczenka-garazha/" target="_blank"><strong>индивидуальные гаражи</strong></a></p>
</td>
<td width="118">
<p align="center" class="western">6 000</p>
</td>
<td width="136">
<p align="center" class="western">12 000</p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western">площадью &lt; 100 кв.м.</p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">15 000</span></p>
</td>
<td width="136">
<p align="center" class="western">20 000</p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western">от 100-500 кв.м.</p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">20 000</span></p>
</td>
<td width="136">
<p align="center" class="western">25 000</p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western" lang="en-US"><span lang="ru-RU">500-1000 кв.м.</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">30 000</span></p>
</td>
<td width="136">
<p align="center" class="western">40 000</p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western" lang="en-US"><span lang="ru-RU">1 000-3 000 кв.м.</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">35 000</span></p>
</td>
<td width="136">
<p align="center" class="western">45 000</p>
</td>
<td width="62">
<p align="center" class="western">7</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western" lang="en-US"><span lang="ru-RU">3 000-5 000 кв.м.</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">40 000</span></p>
</td>
<td width="136">
<p align="center" class="western">45 000</p>
</td>
<td width="62">
<p align="center" class="western">10</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western" lang="en-US"><span lang="ru-RU">5 000-10 000 кв.м.</span></p>
</td>
<td width="118">
<p align="center" class="western">50 000</p>
</td>
<td width="136">
<p align="center" class="western">60 000</p>
</td>
<td width="62">
<p align="center" class="western">10</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western" lang="en-US"><span lang="ru-RU">&gt; 10 000 кв.м.</span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">60 000 и выше</p>
</td>
<td width="136">
<p align="center" class="western">с коэффициентом 1,2</p>
</td>
<td width="62">
<p align="center" class="western">10</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western">при наличии в составе объекта оценки земельного участка, стоимость увеличивается</p>
</td>
<td valign="bottom" width="118">
<p class="western" lang="en-US"><span lang="ru-RU">от 10 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">с коэффициентом 1,2</span></p>
</td>
<td width="62">
<p align="center" class="western">+ 2</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Оценка величины арендной ставки за пользование объектами </p>
</td>
<td valign="bottom" width="118">
<p class="western">+20% к тарифу</p>
</td>
<td width="136">
<p align="center" class="western">1,2</p>
</td>
<td width="62">
<p align="center" class="western">+ 3</p>
</td>
</tr>
<tr>
<td height="14" valign="bottom" width="364">
<p class="western"><strong><a href="/uslugi-ekspertizyi/zemleustroitelnaya-ekspertiza/" target="_blank">Оценка земельных участков</a><strong></strong></strong></p>
</td>
<td valign="bottom" width="118">
<p class="western"> </p>
</td>
<td width="136">
<p align="center" class="western">1,2</p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western">некоммерческого назначения площадью до 30 сот.</p>
</td>
<td width="118">
<p align="center" class="western">6 000</p>
</td>
<td width="136">
<p align="center" class="western">10 000</p>
</td>
<td width="62">
<p align="center" class="western">3-5</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western">некоммерческого назначения от 31 сот. до 1 га</p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">15 000</span></p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">с коэффициентом 1,2</span></p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western">коммерческого назначения </p>
</td>
<td width="118">
<p align="center" class="western">от 20 000</p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">с коэффициентом 1,2</span></p>
</td>
<td width="62">
<p align="center" class="western">5</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western">сельскохозяйственного назначения</p>
</td>
<td width="118">
<p align="center" class="western">20 000</p>
</td>
<td width="136">
<p align="center" class="western">1,2</p>
</td>
<td width="62">
<p align="center" class="western">10</p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western">Ретроспективная оценка объектов (на дату в прошлом)</p>
</td>
<td width="118">
<p align="center" class="western">+ 20% к тарифу</p>
</td>
<td width="136">
<p align="center" class="western">1,2</p>
</td>
<td width="62">
<p align="center" class="western">+ 3</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU"><strong><a href="/uslugi-oczenki/oczenka-avtotransporta/" target="_blank">Оценка рыночной стоимости транспортных средств</a></strong></span></p>
</td>
<td valign="bottom" width="118">
<p class="western"> </p>
</td>
<td width="136">
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western" lang="en-US"><span lang="ru-RU">легковые автомобили при количестве:</span></p>
<p align="right" class="western">1 единица</p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU">2-3 единицы</span></p>
<p align="right" class="western">4-5 единиц</p>
<p align="right" class="western">6-10 единиц</p>
<p align="right" class="western">10-30 единиц</p>
<p align="right" class="western">*расчет восстановительного ремонта при наличии повреждений не учтен</p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">5 000</span></p>
<p align="center" class="western">4 000</p>
<p align="center" class="western">3 500*</p>
<p align="center" class="western">3 000</p>
<p align="center" class="western">2 500*</p>
<p align="center" class="western"> </p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">8 000</span></p>
<p align="center" class="western">6 000</p>
<p align="center" class="western">4 500*</p>
<p align="center" class="western">4 000</p>
<p align="center" class="western">3 500*</p>
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western">3-5</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western" lang="en-US"><span lang="ru-RU">грузовые, специальные автомобили при количестве:</span></p>
<p align="right" class="western">1 единица</p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU">2-3 единицы </span></p>
<p align="right" class="western">4-5 единиц</p>
<p align="right" class="western">6-10 единиц</p>
<p align="right" class="western">10-30 единиц</p>
<p align="right" class="western">*расчет восстановительного ремонта при наличии повреждений не учтен</p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">5 500*</span></p>
<p align="center" class="western">5 000*</p>
<p align="center" class="western">4 500*</p>
<p align="center" class="western">4 000*</p>
<p align="center" class="western">3 500*</p>
<p align="center" class="western"> </p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">8 000*</span></p>
<p align="center" class="western">7 000*</p>
<p align="center" class="western">6 000</p>
<p align="center" class="western">5 000</p>
<p align="center" class="western">4 500</p>
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western">3-5</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western">яхты, катера, лодки</p>
</td>
<td width="118">
<p align="center" class="western">8 000</p>
</td>
<td width="136">
<p align="center" class="western">10 000</p>
</td>
<td width="62">
<p align="center" class="western">5-7</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western">прогулочные судна</p>
</td>
<td width="118">
<p align="center" class="western">20 000</p>
</td>
<td width="136">
<p align="center" class="western">30 000</p>
</td>
<td width="62">
<p align="center" class="western">10-15</p>
</td>
</tr>
<tr valign="bottom">
<td height="153" width="364">
<p align="right" class="western" lang="en-US"><span lang="ru-RU">Оценка рыночной стоимости серийного оборудования, оргтехники при количестве:</span></p>
<p align="right" class="western">1 единица</p>
<p align="right" class="western" lang="en-US"><span lang="ru-RU">2-3 единицы </span></p>
<p align="right" class="western">4-5 единиц</p>
<p align="right" class="western">6-10 единиц</p>
<p align="right" class="western">10-30 единиц</p>
<p align="right" class="western">30-50 единиц</p>
<p align="right" class="western">50-100 единиц</p>
<p align="right" class="western">&gt;100 единиц</p>
</td>
<td width="118">
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
<p align="center" class="western">3 500</p>
<p align="center" class="western">3 000</p>
<p align="center" class="western">2 500</p>
<p align="center" class="western">2 000</p>
<p align="center" class="western">1 500</p>
<p align="center" class="western">1 000</p>
<p align="center" class="western">850</p>
<p align="center" class="western">700</p>
</td>
<td width="136">
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
<p align="center" class="western">6 000</p>
<p align="center" class="western">5 000</p>
<p align="center" class="western">4 000</p>
<p align="center" class="western">3 000</p>
<p align="center" class="western">2 000</p>
<p align="center" class="western">1 500</p>
<p align="center" class="western">1 000</p>
<p align="center" class="western">800</p>
</td>
<td width="62">
<p align="center" class="western">от 3</p>
</td>
</tr>
<tr>
<td height="23" valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU">Оценка рыночной стоимости специального оборудования, станков с ЧПУ, специальной техники</span></p>
</td>
<td colspan="2" valign="bottom" width="269">
<p align="center" class="western">С коэффициентом 2 от цен за оценку серийного оборудования</p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Оценка рыночной стоимости технологической линии в зависимости от количества узлов и агрегатов</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">От 15 000</span></p>
</td>
<td valign="bottom" width="136">
<p align="center" class="western">20 000</p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Оценка бизнеса, акций, долей в уставном капитале</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">20 000</span></p>
</td>
<td width="136">
<p align="center" class="western">30 000</p>
</td>
<td width="62">
<p align="center" class="western">15-30</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Оценка акций, котируемых на ОРЦБ</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">2 000</p>
</td>
<td width="136">
<p align="center" class="western">5 000</p>
</td>
<td width="62">
<p align="center" class="western">5-10</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">Оценка дебиторской задолженности</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">15 000</span></p>
</td>
<td width="136">
<p align="center" class="western">25 000</p>
</td>
<td width="62">
<p align="center" class="western">5-10</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU"><strong>Оценка стоимости восстановительного ремонта (ущерба) внутренней отделки</strong></span></p>
</td>
<td valign="bottom" width="118">
<p class="western"></p>
</td>
<td width="136">
<p align="center" class="western"></p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">жилых помещений площадью повреждения до 30 кв.м. (не более 2 помещений)</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">8 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">15 000</p>
</td>
<td width="62">
<p align="center" class="western">10-12</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">жилых помещений площадью повреждения до 60 кв.м. (не более 3 помещений)</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">10 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">18 000</p>
</td>
<td width="62">
<p align="center" class="western">10-12</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">жилых помещений площадью повреждения более 60 кв.м. (не более 4 помещений)</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">12 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">20 000</p>
</td>
<td width="62">
<p align="center" class="western">10-12</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">дополнительное помещение в жилом объекте</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">3 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">5 000</p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">нежилых помещений площадью повреждения до 100 кв.м. (не более 3 помещений)</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">15 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">25 000</p>
</td>
<td width="62">
<p align="center" class="western">15-20</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU">нежилых помещений площадью повреждения до 500 кв.м. (не более 5 помещений)</span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">30 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">50 000</p>
</td>
<td width="62">
<p align="center" class="western">15-20</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU">нежилых помещений площадью повреждения более 500 кв.м.</span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">от 35 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">60 000</p>
</td>
<td width="62">
<p align="center" class="western">15-20</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">дополнительное помещение в нежилом объекте</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">5 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">7 000</p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU"><strong>Оценка стоимости восстановительного ремонта (ущерба) конструктивных элементов</strong></span></p>
</td>
<td valign="bottom" width="118">
<p class="western"> </p>
</td>
<td width="136">
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">жилых помещений площадью повреждения до 30 кв.м.</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">10 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">15 000</p>
</td>
<td width="62">
<p align="center" class="western">10-12</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">жилых помещений площадью повреждения до 60 кв.м.</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">12 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">17 000</p>
</td>
<td width="62">
<p align="center" class="western">10-12</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">жилых помещений площадью повреждения более 60 кв.м.</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">15 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">20 000</p>
</td>
<td width="62">
<p align="center" class="western">10-12</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western">нежилых помещений площадью повреждения до 100 кв.м.</p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western">20 000 руб.</p>
</td>
<td width="136">
<p align="center" class="western">25 000</p>
</td>
<td width="62">
<p align="center" class="western">15-20</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU">нежилых помещений площадью повреждения до 500 кв.м.</span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">30 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">50 000</p>
</td>
<td width="62">
<p align="center" class="western">15-20</p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span lang="ru-RU">нежилых помещений площадью повреждения более 500 кв.м.</span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span lang="ru-RU">от 35 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">60 000</p>
</td>
<td width="62">
<p align="center" class="western">15-20</p>
</td>
</tr>
<tr>
<td colspan="4" valign="bottom">
<p class="western" lang="en-US"><strong>Прочие услуги</strong></p>
</td>
</tr>
<tr>
<td valign="top" width="364">
<p class="western">Выезд эксперта для осмотра объекта (транспорт заказчика) в пределах г. Самара, руб./час.</p>
</td>
<td width="118">
<p class="western" lang="en-US"><span lang="ru-RU">750 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="top" width="364">
<p class="western">Выезд эксперта для осмотра объекта (транспорт исполнителя), в пределах г. Самара</p>
</td>
<td width="118">
<p class="western">750 руб.</p>
</td>
<td width="136">
<p align="center" class="western">-</p>
</td>
<td width="62">
<p align="center" class="western">1-2 дня после заявки</p>
</td>
</tr>
<tr>
<td valign="top" width="364">
<p class="western">Выезд эксперта для осмотра объекта (транспорт заказчика) за пределы г. Самара, руб./час.</p>
</td>
<td width="118">
<p class="western" lang="en-US"><span lang="ru-RU">750 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">-</p>
</td>
<td width="62">
<p align="center" class="western">1-2 дня после заявки</p>
</td>
</tr>
<tr>
<td valign="top" width="364">
<p class="western">Выезд эксперта для осмотра объекта (транспорт исполнителя), за пределы г. Самара, руб./км.</p>
</td>
<td width="118">
<p class="western" lang="en-US"><span lang="ru-RU">22 руб./км от черты города в обе стороны + 750 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">-</p>
</td>
<td width="62">
<p align="center" class="western">1-2 дня после заявки</p>
</td>
</tr>
<tr>
<td valign="top" width="364">
<p class="western">Выезд эксперта в суд</p>
</td>
<td width="118">
<p class="western" lang="en-US"><span lang="ru-RU">5 000 руб. за первые 2 часа + транспортные расходы + 2 500 руб./час сверх 2-х часов</span></p>
</td>
<td width="136">
<p align="center" class="western">-</p>
</td>
<td width="62">
<p align="center" class="western">Не менее 7 дней до даты судебного заседания</p>
</td>
</tr>
<tr>
<td valign="top" width="364">
<p class="western">Копия отчета (Заключения)</p>
</td>
<td width="118">
<p class="western" lang="en-US"><span lang="ru-RU">1500 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">-</p>
</td>
<td width="62">
<p align="center" class="western">1</p>
</td>
</tr>
<tr>
<td valign="top" width="364">
<p class="western">ТЕЛЕГРАММА</p>
</td>
<td width="118">
<p class="western" lang="en-US"><span lang="ru-RU">800 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western">-</p>
</td>
<td width="62">
<p align="center" class="western">1</p>
</td>
</tr>
</tbody>
</table>