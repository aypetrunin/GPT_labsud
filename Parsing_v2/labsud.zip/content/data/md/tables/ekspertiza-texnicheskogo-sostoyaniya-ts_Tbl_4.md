# Экспертиза технического состояния ТС [https://federallab.ru/uslugi-ekspertizyi/avtotexnicheskaya-ekspertiza/ekspertiza-texnicheskogo-sostoyaniya-ts/]
## 
Стоимость и сроки
<table>
<tbody>
<tr>
<th><span>Экспертиза оборудования, ТС, прочего имущества в силу частичной или полной гибели для списания в зависимости от количества</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>1-3 руб./ед.</td>
<td>3 000 руб.</td>
<td>6 000 р.</td>
<td colspan="1" rowspan="5">5-10 дней</td>
</tr>
<tr>
<td>4-5 руб./ед.</td>
<td>2 500 руб.</td>
<td>5 000 р.</td>
</tr>
<tr>
<td>6-10 руб./ед.</td>
<td>2 000 руб.</td>
<td>4 000 р.</td>
</tr>
<tr>
<td>10-30 руб./ед.</td>
<td>1 750 руб.</td>
<td>3 500 р.</td>
</tr>
<tr>
<td>30-50 руб./ед.</td>
<td>1 500 руб.</td>
<td>3 000 р.</td>
</tr>
</tbody>
</table>