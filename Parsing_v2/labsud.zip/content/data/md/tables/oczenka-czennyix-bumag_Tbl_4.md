# Оценка ценных бумаг [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-czennyix-bumag/]
## 
Стоимость и сроки
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка акций, котируемых на ОРЦБ</td>
<td>2 000 руб.</td>
<td>5 000 руб.</td>
<td>5-10 дней</td>
</tr>
</tbody>
</table>