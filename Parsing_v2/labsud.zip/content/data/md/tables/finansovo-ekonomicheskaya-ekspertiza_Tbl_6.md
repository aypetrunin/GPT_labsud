# Финансово-экономическая экспертиза [https://federallab.ru/uslugi-ekspertizyi/finansovo-ekonomicheskaya-ekspertiza/]
## 
Сроки проведения экспертизы
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Бухгалтерская экспертиза</td>
<td>Минимальная стоимость досудебного исследования, руб.</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения, дн.</td>
</tr>
<tr>
<td>Экспертиза бухгалтерской (финансовой отчетности)</td>
<td>от 15 000</td>
<td>1,2</td>
<td>7-15</td>
</tr>
<tr>
<td>Экспертиза первичных документов</td>
<td>от 15 000</td>
<td>1,2</td>
<td>7-15</td>
</tr>
<tr>
<td>Анализ финансово-хозяйственной деятельности</td>
<td>от 30 000</td>
<td>1,2</td>
<td>10-20</td>
</tr>
<tr>
<td>Экспертиза преднамеренности и фиктивности банкротств</td>
<td>от 20 000</td>
<td>1,2</td>
<td>20-30</td>
</tr>
</tbody>
</table>