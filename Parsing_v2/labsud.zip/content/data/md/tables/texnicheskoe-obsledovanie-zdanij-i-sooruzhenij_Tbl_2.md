# Техническое обследование зданий и сооружений [https://federallab.ru/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/texnicheskoe-obsledovanie-zdanij-i-sooruzhenij/]
## 
Стоимость и сроки
<table>
<tbody>
<tr>
<th><span>Строительно-техническая экспертиза</span></th>
<th>Срок</th>
<th>Цена</th>
</tr>
<tr>
<td>Экспертиза по определению объема фактически выполненных строительно-монтажных работ</td>
<td>5-15 дней</td>
<td>от 15 000 руб.</td>
</tr>
<tr>
<td>Экспертиза соответствия расположения строений на участке требованиям нормативных документов</td>
<td>5-10 дней</td>
<td>от 20 000 руб.</td>
</tr>
</tbody>
</table>