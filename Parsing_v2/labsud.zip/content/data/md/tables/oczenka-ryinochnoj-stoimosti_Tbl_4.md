# Оценка рыночной стоимости [https://federallab.ru/uslugi-oczenki/oczenka-ryinochnoj-stoimosti/]
## 
Экономические экспертизы, оценщик 1 категории, член экспертного совета СРО, стаж работы с 2006 года
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Срок</th>
<th>Цена</th>
</tr>
<tr>
<td>Оценка квартир</td>
<td>2</td>
<td>от 3 000р.</td>
</tr>
<tr>
<td>Оценка жилых домов с земельными участками</td>
<td>5-10</td>
<td>от 9 000р.</td>
</tr>
<tr>
<td>Оценка нежилых помещений</td>
<td> </td>
<td>от 9 000р.</td>
</tr>
<tr>
<td>Оценка величины арендной ставки за пользование объектами</td>
<td>+ 3</td>
<td>+ 20% к тарифу</td>
</tr>
<tr>
<td>Оценка земельных участков</td>
<td>5</td>
<td>6 000р.</td>
</tr>
<tr>
<td>Ретроспективная оценка объектов (на дату в прошлом)</td>
<td>+ 3</td>
<td>+ 20% к тарифу</td>
</tr>
<tr>
<td>Оценка транспортных средств</td>
<td> </td>
<td>от 2 500р.</td>
</tr>
<tr>
<td>Оценка оборудования</td>
<td>от 3</td>
<td>от 500р.</td>
</tr>
<tr>
<td>Оценка бизнеса, акций, долей в уставном капитале</td>
<td>15-30</td>
<td>от 15 000р.</td>
</tr>
<tr>
<td>Оценка акций, котируемых на ОРЦБ</td>
<td>5-10</td>
<td>от 2 000р.</td>
</tr>
<tr>
<td>Оценка дебиторской задолженности</td>
<td>10-15</td>
<td>от 15 000р.</td>
</tr>
<tr>
<td>Оценка стоимости восстановительного ремонта (ущерба)</td>
<td>10-12</td>
<td>от 8 000р.</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western">Оценка для нотариуса</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>2 000</strong></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western">Письменная справка о средней рыночной стоимости</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>2 000</strong></p>
</td></tr>
</tbody>
</table>