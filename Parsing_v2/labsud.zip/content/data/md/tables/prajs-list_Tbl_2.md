# Прайс-лист [https://federallab.ru/prajs-list/]
## 

<table>
<thead>
<tr valign="bottom">
<td rowspan="2" style="width: 5%;">
<p align="center" class="western"><strong>№ п/п</strong></p>
</td>
<td rowspan="2" style="width: 36%;">
<p align="center" class="western"><strong>Наименование работ, услуг</strong></p>
</td>
<td colspan="2" style="width: 32%;">
<p align="center" class="western"><strong>Стоимость независимой досудебной экспертизы, руб</strong></p>
</td>
<td colspan="3" style="width: 86%;">
<p align="center" class="western"><strong>Стоимость судебной экспертизы, руб</strong></p>
</td>
</tr>
<tr>
<td style="width: 17.1707%;background:#D5DEEF;" valign="bottom">
<p align="center" class="western"><strong>Легковые а/м</strong></p>
</td>
<td style="width: 14.8293%;background:#D5DEEF;" valign="bottom">
<p align="center" class="western"><strong>Грузовые а/м и автобусы</strong></p>
</td>
<td style="width: 21%;background:#D5DEEF;" valign="bottom">
<p align="center" class="western"><strong>Легковые а/м</strong></p>
</td>
<td colspan="2" style="width: 65%;background:#D5DEEF;" valign="bottom">
<p align="center" class="western"><strong>Грузовые а/м и автобусы</strong></p>
</td>
</tr>
</thead>
<tbody>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western" lang="en-US"><strong>I</strong></p>
</td>
<td colspan="6" style="width: 68%;" valign="top">
<p class="western"><strong>Составления акта осмотра (повреждений)</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Составление акта осмотра (повреждений) не &gt; 1 позиции</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">1050</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">1200</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">2100</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">2400</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Составление акта осмотра (повреждений) с включением от 2 до 3 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">1150</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">1350</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">2300</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">2700</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 4 до 5 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">1350</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">1450</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">2700</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">2900</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 6 до 10 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">1550</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">2000</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">3100</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">4000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 11 до 20 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">1750</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">2300</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">3500</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">4600</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 21 до 30 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">2000</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">2550</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">4000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">5100</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 31 до 40 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">2300</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">3100</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">4600</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">6200</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 41 до 50 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">2750</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">3400</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">5500</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">6800</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 51 до 60 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">3000</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">3900</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">6000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">7800</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 61 позиции и более</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">3500</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">4650</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">7000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">9300</p>
</td>
</tr>
<tr valign="top">
<td style="width: 5%;">
<p align="center" class="western" lang="en-US"><strong>II</strong></p>
</td>
<td colspan="6" style="width: 154%;">
<p class="western"><strong>Расчет стоимости ремонта автотранспортного средства, подготовка заключения</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Расчет стоимости ремонта транспортного средства по готовому акту осмотра, при включении в акт осмотра (повреждений) не &gt; 1 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">1700</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">1850</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">5000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">5000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western" lang="en-US"> <span lang="ru-RU">То же, при включении в акта осмотра (повреждений) с включением от 2 до 3 позиций</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">1950</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">2550</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">7000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">8000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 4 до 5 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">2300</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">3050</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">7000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">8000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 6 до 10 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">3050</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">3750</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">9000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">10000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 11 до 20 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">3700</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">4750</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">10000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">11000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 21 до 30 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">4250</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">5600</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">12000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">13000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 31 до 40 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">4850</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">6150</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">14000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">15000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 41 до 50 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">5600</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">7250</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">15000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">16000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 51 до 60 позиций</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">6150</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">8250</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">15000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">16000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">То же, с включением от 61 позиции и более</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">6950</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">9100</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">17000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">18000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western" lang="en-US"><strong>III</strong></p>
</td>
<td colspan="6" style="width: 68%;" valign="top">
<p class="western"><strong>Прочие расчеты</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Определение величины утраты товарной стоимости (без расчета стоимости ремонта)</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">3000</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">3650</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">6000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">8000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Определение рыночной стоимости транспортных средств</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">4300</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">5500</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">6000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">7000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Составление акта разногласий по калькуляциям (счетам) других организаций (по готовому расчету), экспертиза по нескольким актам осмотра</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">1500</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">2000</p>
</td>
<td colspan="3" style="width: 86%;" valign="bottom">
<p align="center" class="western">из расчета акта по наибольшему или совокупному количеству повреждений с коэффициентом 1,5</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Расчет стоимости годных остатков</p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western">3000</p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western">3500</p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western">от 6000</p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western">от 7000</p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western" lang="en-US"><strong>IV</strong></p>
</td>
<td colspan="6" style="width: 68%;" valign="top">
<p class="western"><strong>Прочие услуги</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Проверка счетов СТО (без оформления акта разногласий)</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>700</strong></p>
</td>
<td colspan="3" style="width: 86%;" valign="bottom">
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Выезд эксперта для осмотра объекта (транспорт исполнителя), в пределах г. Самара, 1 час, оплачивается не менее 2 часов</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>750</strong></p>
</td>
<td colspan="3" style="width: 86%;" valign="bottom">
<p align="center" class="western"><strong>750</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Выезд эксперта для осмотра объекта (транспорт исполнителя), за пределы Самары, руб./км.</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>20</strong></p>
</td>
<td colspan="3" style="width: 86%;" valign="bottom">
<p align="center" class="western"><strong>20</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Выезд эксперта в суд, первые 2 часа</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>3 700</strong></p>
</td>
<td colspan="3" rowspan="2" style="width: 86%;" valign="bottom">
<p align="center" class="western"><strong>первое заседание не оплачивается</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Выезд эксперта в суд, свыше 2-х часов, руб./час</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>1500</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Копия отчета (Заключения)</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>700</strong></p>
</td>
<td colspan="3" style="width: 86%;" valign="bottom">
<p align="center" class="western"><strong>1000 при согласовании с судом</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Телеграмма</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>600</strong></p>
</td>
<td colspan="3" style="width: 86%;" valign="bottom">
<p align="center" class="western"><strong>600</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Оценка для нотариуса</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>2 000</strong></p>
</td>
</tr>
<tr>
<td style="width: 5%;" valign="top">
<p align="center" class="western"> </p>
</td>
<td style="width: 36%;" valign="top">
<p class="western">Письменная справка о средней рыночной стоимости</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>2 000</strong></p>
</td></tr>
</tbody>
</table>