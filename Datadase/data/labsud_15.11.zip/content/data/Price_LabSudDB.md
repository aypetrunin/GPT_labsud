# Экспертиза смет и договоров [https://federallab.ru/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/ekspertiza-smet-i-dogovorov/]
## 
Экспертиза проектно сметной документации — это практически неотъемлемая часть любого более-менее крупного строительства. Она необходима, чтобы миновать разногласия или урегулировать конфликт между заказчиком и исполнителем, возникший во время обсуждения стоимости работ и закупочных материалов.
<table>
<tbody>
<tr>
<th><span>Строительно-техническая экспертиза</span></th>
<th>Срок</th>
<th>Цена</th>
</tr>
<tr>
<td>Экспертиза качества внутренней отделки</td>
<td>5-10 дней</td>
<td>от 10 000 руб.</td>
</tr>
<tr>
<td>Экспертиза качества строительно-монтажных работ</td>
<td>5-15 дней</td>
<td>от 20 000 руб.</td>
</tr>
<tr>
<td>Экспертиза по определению объема фактически выполненных строительно-монтажных работ</td>
<td>5-15 дней</td>
<td>от 15 000 руб.</td>
</tr>
<tr>
<td>Экспертиза оконных конструкций</td>
<td>5-10 дней</td>
<td>от 3 000 руб.</td>
</tr>
<tr>
<td>Экспертиза соответствия расположения строений на участке требованиям нормативных документов</td>
<td>5-10 дней</td>
<td>от 20 000 руб.</td>
</tr>
<tr>
<td>Экспертиза по отнесению объекта к тому или иному типу (недвижимости, сооружению, стационарному/нестационарному объекту и т.п.)</td>
<td>5-7 дней</td>
<td>от 15 000 руб.</td>
</tr>
</tbody>
</table># Экспертиза проекта [https://federallab.ru/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/ekspertiza-proekta/]
## 
Сложность проведения подобной экспертной оценки в Самаре, как и в любом другом городе, заключается в том, что анализировать приходится здание, которое по каким-либо причинам еще не возведено или его строительство заморожено.
<table>
<tbody>
<tr>
<th><span>Строительно-техническая экспертиза</span></th>
<th>Срок</th>
<th>Цена</th>
</tr>
<tr>
<td>Экспертиза качества внутренней отделки</td>
<td>5-10 дней</td>
<td>от 10 000 руб.</td>
</tr>
<tr>
<td>Экспертиза качества строительно-монтажных работ</td>
<td>5-15 дней</td>
<td>от 20 000 руб.</td>
</tr>
<tr>
<td>Экспертиза по определению объема фактически выполненных строительно-монтажных работ</td>
<td>5-15 дней</td>
<td>от 15 000 руб.</td>
</tr>
<tr>
<td>Экспертиза оконных конструкций</td>
<td>5-10 дней</td>
<td>от 3 000 руб.</td>
</tr>
<tr>
<td>Экспертиза соответствия расположения строений на участке требованиям нормативных документов</td>
<td>5-10 дней</td>
<td>от 20 000 руб.</td>
</tr>
<tr>
<td>Экспертиза по отнесению объекта к тому или иному типу (недвижимости, сооружению, стационарному/нестационарному объекту и т.п.)</td>
<td>5-7 дней</td>
<td>от 15 000 руб.</td>
</tr>
</tbody>
</table># Технико-криминалистическая экспертиза [https://federallab.ru/uslugi-ekspertizyi/texniko-kriminalisticheskaya-ekspertiza/]
## 
В Федеральном законе «Об информации, информатизации и защите информации» сформулировано понятие документа: «Документ – это зафиксированная на материальном носителе информация с реквизитами, позволяющими её идентифицировать». В Комментарии к УК под документом понимается надлежащим образом оформленный материальный носитель каких-либо сведений, предназначенный для удостоверения юридически значимого факта (деяния или события) – «информация, отображаемая на бумаге, фото-, кино-, аудио- или видеопленке, пластмассе, существующая в виде компьютерной записи или в иной, воспринимаемой человеком материальной форме».
<table>
<tbody>
<tr>
<td>Консультации при назначении технической экспертизы документов</td>
<td>от 3 000 руб.</td>
<td>от 1 дня</td>
</tr>
</tbody>
</table># Товарная экспертиза [https://federallab.ru/uslugi-ekspertizyi/tovarnaya-ekspertiza/]
## 
Основными объектами товарной экспертизы являются потребительские товары, т.е. продукция, реализуемая потребителю и используемая им для личных целей.
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td><a href="https://federallab.ru/uslugi-ekspertizyi/tovarnaya-ekspertiza/ekspertiza-telefonov-i-planshetov/">Экспертиза сотовых телефонов и электротехники, бытового оборудования и бытовой техники при стоимости товара</a></td>
<td>Минимальная стоимость досудебного исследования, руб.</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения</td>
</tr>
<tr>
<td style="text-align:right">3 000 – 5 000 руб. </td>
<td> 1 500</td>
<td> 3 000</td>
<td colspan="1" rowspan="7"> 5 дней</td>
</tr>
<tr>
<td style="text-align:right">5 001 – 10 000 руб. </td>
<td> 2 000</td>
<td> 4 000</td>
</tr>
<tr>
<td style="text-align:right">10 001 - 15 000 руб. </td>
<td> 3 000</td>
<td> 6 000</td>
</tr>
<tr>
<td style="text-align:right">15 001 - 20 000 руб. </td>
<td> 3 500</td>
<td> 7 000</td>
</tr>
<tr>
<td style="text-align:right">20 001 - 25 000 руб. </td>
<td> 4 000</td>
<td> 8 000</td>
</tr>
<tr>
<td style="text-align:right">25 001 – 30 000 руб. </td>
<td> 5 000</td>
<td> 10 000</td>
</tr>
<tr>
<td style="text-align:right">30 001 руб. и более </td>
<td> 6 000</td>
<td> 12 000</td>
</tr>
<tr>
<td class="table-header_blue"><a href="https://federallab.ru/uslugi-ekspertizyi/tovarnaya-ekspertiza/ekspertiza-mashin-i-mexanizmov/">Экспертиза машин и механизмов, технологического оборудования, ТС, узлов и агрегатов, руб./ед.:</a></td>
<td>
<p> </p>
</td>
<td>
<p> </p>
</td>
<td colspan="1" rowspan="4">5-10 дней</td>
</tr>
<tr>
<td style="text-align:right">при исследовании одной единицы</td>
<td>15 000</td>
<td>25 000</td>
</tr>
<tr>
<td style="text-align:right">при исследовании до 3-х дефектов или до 3-х единиц</td>
<td>10 000</td>
<td>15 000</td>
</tr>
<tr>
<td style="text-align:right">при исследовании 4-5 дефектов или 4-5 единиц</td>
<td>8 000</td>
<td>12 000</td>
</tr>
<tr>
<td class="table-header_blue"><a href="https://federallab.ru/uslugi-ekspertizyi/avtotexnicheskaya-ekspertiza/avtotovarovedcheskaya-ekspertiza/">Экспертиза оборудования, ТС, прочего имущества в силу частичной или полной гибели для списания в зависимости от количества, руб./ед.:</a></td>
<td>
<p> </p>
</td>
<td>
<p> </p>
</td>
<td colspan="1" rowspan="6">5-10 дней</td>
</tr>
<tr>
<td style="text-align:right">1-3 ед</td>
<td>3 000 </td>
<td>6 000</td>
</tr>
<tr>
<td style="text-align:right">4-5 ед.</td>
<td>2 500</td>
<td>5 000</td>
</tr>
<tr>
<td style="text-align:right">6-10 ед.</td>
<td>2 000</td>
<td>4 000</td>
</tr>
<tr>
<td style="text-align:right">10-30 ед.</td>
<td>1 750</td>
<td>3 500</td>
</tr>
<tr>
<td style="text-align:right">30-50 ед.</td>
<td>1 500</td>
<td>3 000</td>
</tr>
<tr>
</tr>
</tbody>
</table># Оценка дома [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-doma/]
## 
Срок проведения работ: от 3 (трех) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка жилых домов с земельными участками</td>
<td>9 000 руб.</td>
<td>13 000 руб.</td>
<td>5-10 дней</td>
</tr>
<tr>
<td>Оценка надворных построек и прочих улучшений земельного участка, руб./единицу: ограждение, уборная, замощение территории </td>
<td>9 000 руб.</td>
<td>13 000 руб.</td>
<td>3 дня</td>
</tr>
<tr>
<td>надворные постройки (кухня, сарай, гараж, баня, бассейн, хозблок)</td>
<td>3 000 руб.</td>
<td>4 000 руб.</td>
<td>3 дня</td>
</tr>
</tbody>
</table># Землеустроительная экспертиза [https://federallab.ru/uslugi-ekspertizyi/zemleustroitelnaya-ekspertiza/]
## 
Земельная экспертиза начинается с восстановления границ участка. Сопоставляются характеристики, полученные измерительным путем с документированными. Далее производится геодезическая съемка объекта и выполняется построение новой схемы в электронном варианте. Часто причиной, по которой заказывается землеустроительная экспертиза, является раздел участка между двумя или более владельцами.
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Вид экспертизы</td>
<td>Минимальная стоимость досудебного исследования, руб.</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения, дн.</td>
</tr>
<tr>
<td class="table-header_blue">Оценка жилых домов с земельными участками</td>
<td>9 000</td>
<td>13 000</td>
<td>5-10</td>
</tr>
<tr>
<td class="table-header_blue">Оценка надворных построек и прочих улучшений земельного участка, руб./единицу:</td>
<td> </td>
<td> </td>
<td colspan="1" rowspan="3">3</td>
</tr>
<tr>
<td style="text-align:right">ограждение, уборная, замощение территории</td>
<td>1 500</td>
<td>2 000</td>
</tr>
<tr>
<td style="text-align:right">надворные постройки (кухня, сарай, гараж, баня, бассейн, хозблок)</td>
<td>3 000</td>
<td>4 000</td>
</tr>
<tr>
<td class="table-header_blue">Оценка земельных участков</td>
<td> </td>
<td>1,2</td>
<td> </td>
</tr>
<tr>
<td style="text-align:right">некоммерческого назначения площадью до 30 сот.</td>
<td>6 000</td>
<td>10 000</td>
<td>3-5</td>
</tr>
<tr>
<td style="text-align:right">некоммерческого назначения площадью от 31 сот. до 1 га</td>
<td>15 000</td>
<td>с коэффициентом 1,2</td>
<td>5</td>
</tr>
<tr>
<td style="text-align:right">коммерческого назначения площадью</td>
<td>20 000</td>
<td>с коэффициентом 1,2</td>
<td>5</td>
</tr>
<tr>
<td style="text-align:right">сельскохозяйственного назначения</td>
<td>20 000</td>
<td>1,2</td>
<td>10</td>
</tr>
</tbody>
</table># Оценка всех видов ущербов [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-vsex-vidov-ushherbov/]
## 
Срок проведения работ: от 5 (пяти) рабочих дней
<table>
<tbody>
<tr>
<th><span>Вид экспертизы</span></th>
<th>Минимальная стоимость досудебного исследования, руб.</th>
<th>Стоимость судебной экспертизы, руб.</th>
<th>Минимальный срок проведения, дн</th>
</tr>
<tr>
<td colspan="4" style="text-align: center">Оценка стоимости восстановительного ремонта (ущерба) внутренней отделки</td>
</tr>
<tr>
<td>жилых помещений площадью повреждения до 30 кв.м.</td>
<td>8 000 руб</td>
<td>1,2</td>
<td>10-12</td>
</tr>
<tr>
<td>жилых помещений площадью повреждения до 60 кв.м.</td>
<td>10 000 руб</td>
<td>1,2</td>
<td>10-12</td>
</tr>
<tr>
<td>жилых помещений площадью повреждения более 60 кв.м.</td>
<td>12 000 руб</td>
<td>1,2</td>
<td>10-12</td>
</tr>
<tr>
<td>нежилых помещений площадью повреждения до 100 кв.м.</td>
<td>15 000 руб</td>
<td>1,2</td>
<td>15-20</td>
</tr>
<tr>
<td>нежилых помещений площадью повреждения до 500 кв.м.</td>
<td>30 000</td>
<td>1,2</td>
<td>15-20</td>
</tr>
<tr>
<td>нежилых помещений площадью повреждения более 500 кв.м.</td>
<td>35 000</td>
<td>1,2</td>
<td>15-20</td>
</tr>
<tr>
<td colspan="4" style="text-align: center">Оценка стоимости восстановительного ремонта (ущерба) конструктивных элементов</td>
</tr>
<tr>
<td>жилых помещений площадью повреждения до 30 кв.м.</td>
<td>5 000 руб</td>
<td>1,2</td>
<td>10-12</td>
</tr>
<tr>
<td>жилых помещений площадью повреждения до 60 кв.м.</td>
<td>7 500 руб</td>
<td>1,2</td>
<td>10-12</td>
</tr>
<tr>
<td>жилых помещений площадью повреждения более 60 кв.м.</td>
<td>10 000 руб</td>
<td>1,2</td>
<td>10-12</td>
</tr>
<tr>
<td>нежилых помещений площадью повреждения до 100 кв.м.</td>
<td>15 000 руб</td>
<td>1,2</td>
<td>15-20</td>
</tr>
<tr>
<td>нежилых помещений площадью повреждения до 500 кв.м.</td>
<td>30 000 руб</td>
<td>1,2</td>
<td>15-20</td>
</tr>
<tr>
<td>нежилых помещений площадью повреждения более 500 кв.м.</td>
<td>от 35 000</td>
<td>1,2</td>
<td>15-20</td>
</tr>
</tbody>
</table># Автотовароведческая экспертиза [https://federallab.ru/uslugi-ekspertizyi/avtotexnicheskaya-ekspertiza/avtotovarovedcheskaya-ekspertiza/]
## 
 
<table border="1" cellpadding="0" cellspacing="0" class="price-list price-list_second">
<tbody>
<tr class="table-header_blue">
<td width="364">
<p align="center" class="western"><span style="font-size: small;"><strong>Оценка рыночной стоимости транспортных средств</strong></span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU"><strong>Минимальная стоимость досудебного исследования</strong></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;"><strong>Стоимость судебной экспертизы</strong></span></p>
</td>
<td width="62">
<p align="center" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU"><strong>Срок проведения</strong></span></span></p>
</td>
</tr>
</tbody>
<tbody>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU">легковые автомобили при количестве:</span></span></p>
<p align="right" class="western"><span style="font-size: small;">1 единица</span></p>
<p align="right" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">2-3 единицы </span></span></span></p>
<p align="right" class="western"><span style="font-size: small;">4-5 единиц</span></p>
<p align="right" class="western"><span style="font-size: small;">6-10 единиц</span></p>
<p align="right" class="western"><span style="font-size: small;">10-30 единиц</span></p>
<p align="right" class="western"><span style="font-size: small;">*расчет стоимости восстановительного ремонта при наличии повреждений не учтен</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU">4 300 руб.*</span></span></p>
<p align="center" class="western"><span style="font-size: small;">3 500 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">3 000 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">2 750 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">2 500 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"> </p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU">6 000</span> <span lang="ru-RU">руб.*</span></span></p>
<p align="center" class="western"><span style="font-size: small;">5 000 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">4 000 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">3 500 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">3 000 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">3-5 дней</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU">грузовые, специальные автомобили при количестве:</span></span></p>
<p align="right" class="western"><span style="font-size: small;">1 единица</span></p>
<p align="right" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU">2-3 единицы </span></span></p>
<p align="right" class="western"><span style="font-size: small;">4-5 единиц</span></p>
<p align="right" class="western"><span style="font-size: small;">6-10 единиц</span></p>
<p align="right" class="western"><span style="font-size: small;">10-30 единиц</span></p>
<p align="right" class="western"><span style="font-size: small;">*расчет стоимости восстановительного ремонта при наличии повреждений не учтен</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU">5 500</span> <span lang="ru-RU">руб.*</span></span></p>
<p align="center" class="western"><span style="font-size: small;">5 000 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">4 500 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">4 000 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">3 500 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"> </p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU">7 000</span> <span lang="ru-RU">руб.*</span></span></p>
<p align="center" class="western"><span style="font-size: small;">6 000 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">5 250 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">4 750 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"><span style="font-size: small;">4 250 <span lang="ru-RU">руб.</span>*</span></p>
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">3-5 дней</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western"><span style="font-size: small;">яхты, катера, лодки</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">7 000 <span lang="ru-RU">р.</span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">10 000 р.</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5-7 дней</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western"><span style="font-size: small;">прогулочные судна</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">15 000 <span lang="ru-RU">р.</span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">20 000 р.</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">10-15 дней</span></p>
</td>
</tr>
</tbody>
</table># Финансово-экономическая экспертиза [https://federallab.ru/uslugi-ekspertizyi/finansovo-ekonomicheskaya-ekspertiza/]
## 
Сроки проведения экспертизы
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Бухгалтерская экспертиза</td>
<td>Минимальная стоимость досудебного исследования, руб.</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения, дн.</td>
</tr>
<tr>
<td>Экспертиза бухгалтерской (финансовой отчетности)</td>
<td>от 15 000</td>
<td>1,2</td>
<td>7-15</td>
</tr>
<tr>
<td>Экспертиза первичных документов</td>
<td>от 15 000</td>
<td>1,2</td>
<td>7-15</td>
</tr>
<tr>
<td>Анализ финансово-хозяйственной деятельности</td>
<td>от 30 000</td>
<td>1,2</td>
<td>10-20</td>
</tr>
<tr>
<td>Экспертиза преднамеренности и фиктивности банкротств</td>
<td>от 20 000</td>
<td>1,2</td>
<td>20-30</td>
</tr>
</tbody>
</table># Оценка недвижимости [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-nedvizhimosti/]
## 

Оценка квартиры
Оценка дачи
Оценка гаража
Оценка дома

<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">Оценка квартир</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">3 000</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">6 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">3</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">Оценка жилых домов с земельными участками</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">9 000</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">13 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5-10</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">Оценка надворных построек и прочих улучшений земельного участка, руб./единицу:</span></span></span></p>
<p align="right" class="western"><span style="font-size: small;">ограждение, уборная, замощение территории</span></p>
<p align="right" class="western"><span style="font-size: small;">надворные постройки (кухня, сарай, гараж, баня, бассейн, хозблок)</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">1 500</span></p>
<p align="center" class="western"><span style="font-size: small;">3 000</span></p>
<p align="center" class="western"> </p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">2 000</span></p>
<p align="center" class="western"><span style="font-size: small;">4 000</span></p>
<p align="center" class="western"> </p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">3</span></p>
<p align="center" class="western"> </p>
<p align="center" class="western"> </p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western"><span style="font-size: small;">Оценка нежилых помещений</span></p>
</td>
<td valign="bottom" width="118">
<p class="western"> </p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western"><span style="font-size: small;">индивидуальные гаражи</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">6 000</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">10 000</span></p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western"><span style="font-size: small;">площадью менее 100 кв.м.</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">15 000</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">18 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western"><span style="font-size: small;">площадью от 100 до 500 кв.м.</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">20 000</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">22 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">площадью от 500 до 1000 кв.м.</span></span></span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">25 000</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">27 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">площадью от 1 000 кв.м. до 3 000 кв.м.</span></span></span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">30 000</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">35 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">7</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">площадью от 3 000 кв.м. до 5 000 кв.м.</span></span></span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">40 000</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">45 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">10</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">площадью от 5 000 кв.м. до 10 000 кв.м.</span></span></span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">50 000</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">60 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">10</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">площадью более 10 000 кв.м.</span></span></span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western"><span style="font-size: small;">60 000 и выше</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">с коэффициентом 1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">10</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p align="right" class="western"><span style="font-size: small;">в случае наличия в составе объекта оценки земельного участка, стоимость увеличивается</span></p>
</td>
<td valign="bottom" width="118">
<p class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">от 10 000 руб.</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">с коэффициентом 1,2</span></span></span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">+ 2</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western"><span style="font-size: small;">Оценка величины арендной ставки за пользование объектами </span></p>
</td>
<td valign="bottom" width="118">
<p class="western"><span style="font-size: small;">+ 20% к тарифу</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">+ 3</span></p>
</td>
</tr>
<tr>
<td height="14" valign="bottom" width="364">
<p class="western"><span style="font-size: small;">Оценка земельных участков</span></p>
</td>
<td valign="bottom" width="118">
<p class="western"> </p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western"><span style="font-size: small;">некоммерческого назначения площадью до 30 сот.</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">6 000</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">10 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">3-5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western"><span style="font-size: small;">некоммерческого назначения площадью от 31 сот. до 1 га</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">15 000</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">с коэффициентом 1,2</span></span></span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western"><span style="font-size: small;">коммерческого назначения </span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">от 20 000</span></p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">с коэффициентом 1,2</span></span></span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p align="right" class="western"><span style="font-size: small;">сельскохозяйственного назначения</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">20 000</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">10</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">Ретроспективная оценка объектов (на дату в прошлом)</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">+ 20% к тарифу</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">+ 3</span></p>
</td>
</tr>
</tbody>
</table># Оценка гаража [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-garazha/]
## 
Срок проведения работ: от 3 (трех) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза нежилых помещений</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Индивидуальные гаражи</td>
<td>6 000 руб.</td>
<td>10 000 руб.</td>
<td></td>
</tr>
</tbody>
</table># Экспертиза границ участков [https://federallab.ru/uslugi-ekspertizyi/zemleustroitelnaya-ekspertiza/ekspertiza-granicz-uchastkov/]
## 
Спорные границы между участками определяются при помощи процедуры межевания. После приобретения земли собственник инициирует проведение межевания для законного определения границ собственного земельного участка. Проводится исследование, геодезические исследования и составляется межевое дело. После этого регистрационным органом выдается паспорт земли с четко определенными границами.
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Вид экспертизы</td>
<td>Минимальная стоимость досудебного исследования, руб.</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения, дн.</td>
</tr>
<tr>
<td>Оценка земельных участков</td>
<td> </td>
<td>1,2</td>
<td> </td>
</tr>
<tr>
<td style="text-align:right">некоммерческого назначения площадью до 30 сот.</td>
<td>6 000</td>
<td>10 000</td>
<td>3-5</td>
</tr>
<tr>
<td style="text-align:right">некоммерческого назначения площадью от 31 сот. до 1 га</td>
<td>15 000</td>
<td>с коэффициентом 1,2</td>
<td>5</td>
</tr>
<tr>
<td style="text-align:right">коммерческого назначения площадью</td>
<td>20 000</td>
<td>с коэффициентом 1,2</td>
<td>5</td>
</tr>
<tr>
<td style="text-align:right">сельскохозяйственного назначения</td>
<td>20 000</td>
<td>1,2</td>
<td>10</td>
</tr>
<tr>
<td>Ретроспективная оценка объектов (на дату в прошлом)</td>
<td>+ 20% к тарифу</td>
<td>1,2</td>
<td>+3</td>
</tr>
</tbody>
</table># Оценка бизнеса [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-biznesa/]
## 
Срок проведения работ: от 7 (семи) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка бизнеса, акций, долей в уставном капитале</td>
<td>от 15 000 руб.</td>
<td>24 000 руб.</td>
<td>15-30 дней</td>
</tr>
</tbody>
</table># Оценка дебиторской и кредиторской задолженности [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-debitorskoj-i-kreditorskoj-zadolzhennosti/]
## 
Срок проведения работ: от 5 (пяти) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка дебиторской задолженности</td>
<td>от 15 000 руб.</td>
<td>24 000 руб.</td>
<td>5-10 дней</td>
</tr>
</tbody>
</table># Экспертиза пластиковых окон ПВХ [https://federallab.ru/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/ekspertiza-plastikovyix-okon-pvx/]
## 
Основными дефектами окон и балконных дверей являются щели, продувание из окон, отсутствие уплотнителей, образование конденсата на окнах и плесени на откосах и стенах, неплотный притвор створок окон и балконных дверей, образование наледи, трещины стеклопакетов, а зачастую даже несоответствие размера заказанных окон фактическим размерам проемов.
<table>
<tbody>
<tr>
<th><span>Строительно-техническая экспертиза</span></th>
<th>Срок, дн.</th>
<th>Цена</th>
</tr>
<tr>
<td>Экспертиза оконных конструкций</td>
<td>5-10</td>
<td>от 3 000 руб.</td>
</tr>
</tbody>
</table># Экспертиза качества строительства [https://federallab.ru/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/ekspertiza-kachestva-stroitelstva/]
## 
Независимая строительная экспертиза может быть проведена в отношении любых объектов: зданий, сооружений, отдельных помещений, фасадов и других элементов строений, а также коммуникаций и иных объектов инфраструктуры. Эксперт может оценить состояние здания, его износ и количество дефектов и ошибок, допущенных в ходе строительства, а также состояние и качество отдельных элементов и выполненных работ: трубопроводов, стяжки, отделки фасадов, электромонтажа и т.д. Предмет экспертизы зависит от предмета самого спора между клиентом и подрядчиком.
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Строительно-техническая экспертиза</td>
<td>Минимальная стоимость досудебного исследования</td>
<td>Стоимость судебной экспертизы</td>
<td>Минимальный срок проведения</td>
</tr>
<tr>
<td>
<p>Экспертиза качества отделки и строительно-монтажных работ, оценка стоимости восстановительного ремонта</p>
</td>
<td>
<p> </p>
</td>
<td>
<p> </p>
</td>
<td colspan="1" rowspan="12" style="text-align:center">5-10 дней</td>
</tr>
<tr>
<td style="text-align:right">жилые помещения площадью до 50 м<sup>2</sup></td>
<td style="text-align:center">8 000 р.*</td>
<td style="text-align:center">15 000 р.*</td>
</tr>
<tr>
<td style="text-align:right">жилые помещения площадью от 51 до 100 м<sup>2</sup></td>
<td style="text-align:center">12 000 р.*</td>
<td style="text-align:center">18 000 р.*</td>
</tr>
<tr>
<td style="text-align:right">жилые помещения площадью от 101 до 300 м<sup>2</sup></td>
<td style="text-align:center">19 000 р.</td>
<td style="text-align:center">30 000 р.</td>
</tr>
<tr>
<td style="text-align:right">жилые помещения площадью более 300 м<sup>2</sup></td>
<td style="text-align:center">25 000 р.</td>
<td style="text-align:center">35 000 р.</td>
</tr>
<tr>
<td style="text-align:right">нежилые помещения до 100 м<sup>2</sup></td>
<td style="text-align:center">15 000 р.</td>
<td style="text-align:center">22 000 р.</td>
</tr>
<tr>
<td style="text-align:right">нежилые помещения от 101 до 300 м<sup>2</sup></td>
<td style="text-align:center">20 000 р.</td>
<td style="text-align:center">28 000 р.</td>
</tr>
<tr>
<td style="text-align:right">нежилые помещения от 300 до 500 м<sup>2</sup></td>
<td style="text-align:center">40 000 р.</td>
<td style="text-align:center">50 000 р.</td>
</tr>
<tr>
<td style="text-align:right">нежилые помещения от 500 до 1000 м<sup>2</sup></td>
<td style="text-align:center">50 000 р.</td>
<td style="text-align:center">60 000 р.</td>
</tr>
<tr>
<td style="text-align:right">нежилые помещения более 1000 м<sup>2</sup></td>
<td style="text-align:center">60 000 р.</td>
<td style="text-align:center">80 000 р.</td>
</tr>
<tr>
<td>*дополнительно составление сметы на устранение дефектов, % от стоимости обследования</td>
<td style="text-align:center">20%</td>
<td style="text-align:center">20%</td>
</tr>
<tr>
<td>*дополнительно составление акта обследования без обмерных работ<br/>
			(не менее 1 ч) /с работами (не &lt;2 ч)<brс></brс></td>
<td style="text-align:center">2500 руб./час</td>
<td style="text-align:center">2500 руб. в час</td>
</tr>
<tr>
<td>Расчет инсоляционного режима земельного участка или жилого строения/ помещения, руб. / объект</td>
<td>15 000 р.</td>
<td> 20 000 р.</td>
<td>5 дней</td>
</tr>
<tr>
<td>Экспертиза по определению объема фактически выполненных строительно-монтажных работ</td>
<td>от 25 000 руб.<br/>
			предел рассчитывается по нормо-часам</td>
<td>от 32 000 руб.<br/>
			предел рассчитывается по нормо-часам</td>
<td>5-15 дней</td>
</tr>
<tr>
<td>
<p>Экспертиза оконных конструкций, дверных полотен</p>
</td>
<td>
<p> </p>
</td>
<td>
<p> </p>
</td>
<td> </td>
</tr>
<tr>
<td style="text-align:right">1 единица</td>
<td>4 500 руб.*</td>
<td>6 000 руб.*</td>
<td> </td>
</tr>
<tr>
<td style="text-align:right">2-3 руб./ед.</td>
<td>3 500 руб.*</td>
<td>5 000 руб.*</td>
<td> </td>
</tr>
<tr>
<td style="text-align:right">4-5 руб./ед.</td>
<td>3 000 руб.*</td>
<td>4 000 руб.*</td>
<td> </td>
</tr>
<tr>
<td style="text-align:right">6-10 руб./ед.</td>
<td>2 500 руб.*</td>
<td>3 000 руб.*</td>
<td> </td>
</tr>
<tr>
<td style="text-align:right">* дополнительно составление акта обследования без обмерных работ (не менее 1 ч) / с обмерными работами (не менее 2 ч)</td>
<td>1 500 руб./час</td>
<td>1 500 руб./час</td>
<td> </td>
</tr>
<tr>
<td>Экспертиза соответствия расположения строений на участке требованиям нормативных документов, руб./объект</td>
<td>12 000 руб./объект</td>
<td>15 000 руб./объект</td>
<td>5 дней</td>
</tr>
<tr>
<td>Экспертиза по отнесению объекта к тому или иному типу (недвижимости, сооружению, стационарному/нестационарному объекту и т.п.)</td>
<td>12 000 р.</td>
<td>15 000 р.</td>
<td>5 дней</td>
</tr>
<tr>
</tr>
</tbody>
</table># Экспертиза по результатам залива и пожара [https://federallab.ru/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/ekspertiza-po-rezultatam-zaliva-i-pozhara/]
## 
Если виновник не согласен – документы, составленные экспертом, можно направить в суд и взыскать компенсацию в судебном порядке. Важно: виновник компенсирует не только ущерб, но и расходы на саму независимую пожарную экспертизу или оценку после залива.
<table border="1" cellpadding="7" cellspacing="0" width="100%">
<thead>
<tr class="table-header_blue">
<td width="364">
<p align="center" class="western"><span style="font-size: small;"><strong>Оценка стоимости восстановительного ремонта (ущерба) внутренней отделки</strong></span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU"><strong>Минимальная стоимость досудебного исследования</strong></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;"><strong>Стоимость судебной экспертизы, руб.</strong></span></p>
</td>
<td width="62">
<p align="center" class="western" lang="en-US"><span style="font-size: small;"><span lang="ru-RU"><strong>Минимальный срок проведения</strong></span></span></p>
</td>
</tr>
</thead>
<tbody>
<tr>
<td valign="bottom" width="364">
<p class="western"><span style="font-size: small;">жилых помещений площадью повреждения до 30 м<sup>2</sup></span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western"><span style="font-size: small;">8 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td colspan="1" rowspan="3" width="62">
<p align="center" class="western"><span style="font-size: small;">10-12 дней</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western"><span style="font-size: small;">жилых помещений площадью повреждения до 60 м<sup>2</sup></span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western"><span style="font-size: small;">10 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western"><span style="font-size: small;">жилых помещений площадью повреждения &gt; 60 м<sup>2</sup></span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western"><span style="font-size: small;">12 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western"><span style="font-size: small;">нежилых помещений площадью повреждения до 100 м<sup>2</sup></span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western"><span style="font-size: small;">15 000 руб.</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td colspan="1" rowspan="3" width="62">
<p align="center" class="western"><span style="font-size: small;">15-20 дней</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">нежилых помещений площадью повреждения до 500 </span></span></span><span style="font-size: small;">м<sup>2</sup></span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">30 000 руб.</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
</tr>
<tr>
<td valign="bottom" width="364">
<p class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">нежилых помещений площадью повреждения &gt; 500 </span></span></span><span style="font-size: small;">м<sup>2</sup></span></p>
</td>
<td valign="bottom" width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">от 35 000 руб.</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
</tr>
</tbody>
</table># Оценка дачи [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-dachi/]
## 
Срок проведения работ: от 3 (трех) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td height="14" valign="bottom" width="364">
<p class="western"><span style="font-size: small;">Оценка земельных участков</span></p>
</td>
<td valign="bottom" width="118">
<p class="western"> </p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">некоммерческого назначения площадью до 30 сот.</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">6 000</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">10 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">3-5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">некоммерческого назначения площадью от 31 сот. до 1 га</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">15 000</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">с коэффициентом 1,2</span></span></span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">коммерческого назначения </span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">от 20 000</span></p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">с коэффициентом 1,2</span></span></span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">сельскохозяйственного назначения</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">20 000</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">10</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">Ретроспективная оценка объектов (на дату в прошлом)</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">+ 20% к тарифу</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">+ 3</span></p>
</td>
</tr>
<tr>
</tr></tbody>
</table># Экспертиза межевого дела [https://federallab.ru/uslugi-ekspertizyi/zemleustroitelnaya-ekspertiza/ekspertiza-mezhevogo-dela/]
## 
Межевание – это установленный определенным регламентом процесс, когда границы определенного участка закрепляются за его собственником. Процедура регулируется законом и производится только лицензированными органами. Согласно межевому делу собственник земли становится ее полноправным хозяином с четко определенной территорией, преступать границы которой сторонние лица не имеют права.
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Оценка земельных участков</td>
<td>Минимальная стоимость досудебного исследования, руб.</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения, дн.</td>
</tr>
<tr>
<td style="text-align:right">некоммерческого назначения площадью до 30 сот.</td>
<td>6 000 руб.</td>
<td>10 000 руб.</td>
<td>3-5 дней</td>
</tr>
<tr>
<td style="text-align:right">некоммерческого назначения площадью от 31 сот. до 1 га</td>
<td>15 000 руб.</td>
<td colspan="1" rowspan="2">с коэффициентом 1,2</td>
<td colspan="1" rowspan="2">5 дней</td>
</tr>
<tr>
<td style="text-align:right">коммерческого назначения площадью</td>
<td>20 000 руб.</td>
</tr>
<tr>
<td style="text-align:right">сельскохозяйственного назначения</td>
<td>20 000 руб.</td>
<td colspan="1" rowspan="2">1,2</td>
<td>10 дней</td>
</tr>
<tr>
<td>Ретроспективная оценка объектов (на дату в прошлом)</td>
<td>+ 20% к тарифу</td>
<td>+3 дня</td>
</tr>
</tbody>
</table># Экспертиза машин и механизмов [https://federallab.ru/uslugi-ekspertizyi/tovarnaya-ekspertiza/ekspertiza-mashin-i-mexanizmov/]
## 
Техническая экспертиза оборудования может потребоваться при поломках, износе, работе техники в непредусмотренных изготовителем условиях, при спорах с компанией, выполняющей гарантийный ремонт, и в других случаях. В рамках этого инженерно-технического исследования можно понять, соответствуют ли реальные характеристики техники заявленным, имеются ли дефекты, и как они возникли, каков остаточный ресурс до следующей экспертизы, ремонта или утилизации.
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Экспертиза машин и механизмов, технологического оборудования, ТС, узлов и агрегатов, руб./ед.</td>
<td>Минимальная стоимость досудебного исследования, руб.</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения</td>
</tr>
<tr>
<td style="text-align:right">при экспертизе одного дефекта одной единицы</td>
<td>15 000</td>
<td>25 000</td>
<td colspan="1" rowspan="3">5-10 дней</td>
</tr>
<tr>
<td style="text-align:right">при экспертизе до 3-х дефектов или до 3-х единиц</td>
<td>10 000</td>
<td>15 000</td>
</tr>
<tr>
<td style="text-align:right">при экспертизе 4-5 дефектов или 4-5 единиц</td>
<td>8 000</td>
<td>12 000</td>
</tr>
<tr>
<td class="table-header_blue">Экспертиза оборудования, ТС, прочего имущества в силу частичной или полной гибели для списания в зависимости от количества, руб./ед.</td>
<td>
<p> </p>
</td>
<td>
<p> </p>
</td>
<td colspan="1" rowspan="6">5-10 дней</td>
</tr>
<tr>
<td style="text-align:right">1-3 ед</td>
<td>3 000</td>
<td>6 000</td>
</tr>
<tr>
<td style="text-align:right">4-5 ед.</td>
<td>2 500</td>
<td>5 000</td>
</tr>
<tr>
<td style="text-align:right">6-10 ед.</td>
<td>2 000</td>
<td>4 000</td>
</tr>
<tr>
<td style="text-align:right">10-30 ед.</td>
<td>1 750</td>
<td>3 500</td>
</tr>
<tr>
<td style="text-align:right">30-50 ед.</td>
<td>1 500</td>
<td>3 000</td>
</tr>
</tbody>
</table># Оценка ценных бумаг [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-czennyix-bumag/]
## 
Данный перечень документов носит предварительный характер и может быть сокращен или расширен после детального ознакомления оценщика с заданием на оценку и параметрами ценной бумаги.
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка акций, котируемых на ОРЦБ</td>
<td>2 000 руб.</td>
<td>5 000 руб.</td>
<td>5-10 дней</td>
</tr>
</tbody>
</table># Экспертиза технического состояния ТС [https://federallab.ru/uslugi-ekspertizyi/avtotexnicheskaya-ekspertiza/ekspertiza-texnicheskogo-sostoyaniya-ts/]
## 

экспертиза двигателя автомобиля и его мощности;
экспертиза кузова;
экспертиза коробки передач;
экспертиза подвески;
экспертиза шасси;
экспертиза бампера;
экспертиза приборов;
экспертиза прочих узлов и агрегатов.

<table>
<tbody>
<tr>
<th><span>Экспертиза оборудования, ТС, прочего имущества в силу частичной или полной гибели для списания в зависимости от количества</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>1-3 руб./ед.</td>
<td>3 000 руб.</td>
<td>6 000 р.</td>
<td colspan="1" rowspan="5">5-10 дней</td>
</tr>
<tr>
<td>4-5 руб./ед.</td>
<td>2 500 руб.</td>
<td>5 000 р.</td>
</tr>
<tr>
<td>6-10 руб./ед.</td>
<td>2 000 руб.</td>
<td>4 000 р.</td>
</tr>
<tr>
<td>10-30 руб./ед.</td>
<td>1 750 руб.</td>
<td>3 500 р.</td>
</tr>
<tr>
<td>30-50 руб./ед.</td>
<td>1 500 руб.</td>
<td>3 000 р.</td>
</tr>
</tbody>
</table># Оценка рыночной стоимости [https://federallab.ru/uslugi-oczenki/oczenka-ryinochnoj-stoimosti/]
## 
Экономические экспертизы, оценщик 1 категории, член экспертного совета СРО, стаж работы с 2006 года
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Срок</th>
<th>Цена</th>
</tr>
<tr>
<td>Оценка квартир</td>
<td>2</td>
<td>от 3 000р.</td>
</tr>
<tr>
<td>Оценка жилых домов с земельными участками</td>
<td>5-10</td>
<td>от 9 000р.</td>
</tr>
<tr>
<td>Оценка нежилых помещений</td>
<td> </td>
<td>от 9 000р.</td>
</tr>
<tr>
<td>Оценка величины арендной ставки за пользование объектами</td>
<td>+ 3</td>
<td>+ 20% к тарифу</td>
</tr>
<tr>
<td>Оценка земельных участков</td>
<td>5</td>
<td>6 000р.</td>
</tr>
<tr>
<td>Ретроспективная оценка объектов (на дату в прошлом)</td>
<td>+ 3</td>
<td>+ 20% к тарифу</td>
</tr>
<tr>
<td>Оценка транспортных средств</td>
<td> </td>
<td>от 2 500р.</td>
</tr>
<tr>
<td>Оценка оборудования</td>
<td>от 3</td>
<td>от 500р.</td>
</tr>
<tr>
<td>Оценка бизнеса, акций, долей в уставном капитале</td>
<td>15-30</td>
<td>от 15 000р.</td>
</tr>
<tr>
<td>Оценка акций, котируемых на ОРЦБ</td>
<td>5-10</td>
<td>от 2 000р.</td>
</tr>
<tr>
<td>Оценка дебиторской задолженности</td>
<td>10-15</td>
<td>от 15 000р.</td>
</tr>
<tr>
<td>Оценка стоимости восстановительного ремонта (ущерба)</td>
<td>10-12</td>
<td>от 8 000р.</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western">Оценка для нотариуса</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>2 000</strong></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western">Письменная справка о средней рыночной стоимости</p>
</td>
<td colspan="2" style="width: 32%;" valign="bottom">
<p align="center" class="western"><strong>2 000</strong></p>
</td></tr>
</tbody>
</table># Оценка квартиры [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-kvartiryi/]
## 
Срок проведения работ: от 2 (двух) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка квартир</td>
<td>3 000 руб.</td>
<td>6 000 руб.</td>
<td>3 дней</td>
</tr>
</tbody>
</table># Строительно-техническая экспертиза [https://federallab.ru/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/]
## 
Стоимость и сроки
<table>
<tbody>
<tr>
<th><span>Строительно-техническая экспертиза</span></th>
<th>Срок</th>
<th>Цена</th>
</tr>
<tr>
<td>Экспертиза качества внутренней отделки</td>
<td>5-10 дней</td>
<td>от 10 000р.</td>
</tr>
<tr>
<td>Экспертиза качества строительно-монтажных работ</td>
<td>5-15 дней</td>
<td>от 20 000р.</td>
</tr>
<tr>
<td>Экспертиза по определению объема фактически выполненных строительно-монтажных работ</td>
<td>5-15 дней</td>
<td>от 15 000р.</td>
</tr>
<tr>
<td>Экспертиза оконных конструкций</td>
<td>5-10 дней</td>
<td>от 3 000р.</td>
</tr>
<tr>
<td>Экспертиза соответствия расположения строений на участке требованиям нормативных документов</td>
<td>5-10 дней</td>
<td>от 20 000р.</td>
</tr>
<tr>
<td>Экспертиза по отнесению объекта к тому или иному типу (недвижимости, сооружению, стационарному/нестационарному объекту и т.п.)</td>
<td>5-7 дней</td>
<td>от 15 000р.</td>
</tr>
</tbody>
</table># Оценка автомобилей [https://federallab.ru/uslugi-ekspertizyi/avtotexnicheskaya-ekspertiza/oczenka-avtomobilej/]
## 
Оценка стоимости восстановительного ремонта (ущерба) ТС
<table border="1" cellpadding="0" cellspacing="0" class="price-list price-list_second">
<tbody>
<tr class="table-header_blue">
<td colspan="1" rowspan="2">№</td>
<td colspan="1" rowspan="2">Услуга</td>
<td colspan="2" rowspan="1">Стоимость независимой досудебной экспертизы, руб.</td>
<td colspan="2" rowspan="1">Стоимость судебной экспертизы, руб</td>
</tr>
<tr class="table-header_blue">
<td>Легковые а/м</td>
<td>Грузовые а/м и автобусы</td>
<td>Легковые а/м</td>
<td>Грузовые а/м и автобусы</td>
</tr>
<tr>
<td>I</td>
<td colspan="5" rowspan="1">Составления акта осмотра (повреждений)</td>
</tr>
<tr>
<td> </td>
<td>Составление акта осмотра (повреждений) не более 1 позиции</td>
<td>1050</td>
<td>1200</td>
<td>2100</td>
<td>2400</td>
</tr>
<tr>
<td> </td>
<td>Составление акта осмотра (повреждений) с включением от 2 до 3 позиций</td>
<td>1150</td>
<td>1350</td>
<td>2300</td>
<td>2700</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 4 до 5 позиций</td>
<td>1350</td>
<td>1450</td>
<td>2700</td>
<td>2900</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 6 до 10 позиций</td>
<td>1550</td>
<td>2000</td>
<td>3100</td>
<td>4000</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 11 до 20 позиций</td>
<td>1750</td>
<td>2300</td>
<td>3500</td>
<td>4600</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 21 до 30 позиций</td>
<td>2000</td>
<td>2550</td>
<td>4000</td>
<td>5100</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 31 до 40 позиций</td>
<td>2300</td>
<td>3100</td>
<td>4600</td>
<td>6200</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 41 до 50 позиций</td>
<td>2750</td>
<td>3400</td>
<td>5500</td>
<td>6800</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 51 до 60 позиций</td>
<td>3000</td>
<td>3900</td>
<td>6000</td>
<td>7800</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 61 позиции и более</td>
<td>3500</td>
<td>4650</td>
<td>7000</td>
<td>9300</td>
</tr>
<tr>
<td>II</td>
<td colspan="5" rowspan="1">Расчет стоимости ремонта автотранспортного средства, подготовка заключения</td>
</tr>
<tr>
<td> </td>
<td>Расчет стоимости ремонта транспортного средства по готовому акту осмотра, при включении в акт осмотра (повреждений) не более 1 позиций</td>
<td>1700</td>
<td>1850</td>
<td>5000</td>
<td>5000</td>
</tr>
<tr>
<td> </td>
<td>То же, при включении в акта осмотра (повреждений) с включением от 2 до 3 позиций</td>
<td>1950</td>
<td>2550</td>
<td>7000</td>
<td>8000</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 4 до 5 позиций</td>
<td>2300</td>
<td>3050</td>
<td>7000</td>
<td>8000</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 6 до 10 позиций</td>
<td>3050</td>
<td>3750</td>
<td>9000</td>
<td>10000</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 11 до 20 позиций</td>
<td>3700</td>
<td>4750</td>
<td>10000</td>
<td>11000</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 21 до 30 позиций</td>
<td>4250</td>
<td>5600</td>
<td>12000</td>
<td>13000</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 31 до 40 позиций</td>
<td>4850</td>
<td>6150</td>
<td>14000</td>
<td>15000</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 41 до 50 позиций</td>
<td>5600</td>
<td>7250</td>
<td>15000</td>
<td>16000</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 51 до 60 позиций</td>
<td>6150</td>
<td>8250</td>
<td>15000</td>
<td>16000</td>
</tr>
<tr>
<td> </td>
<td>То же, с включением от 61 позиции и более</td>
<td>6950</td>
<td>9100</td>
<td>17000</td>
<td>18000</td>
</tr>
<tr>
<td>III</td>
<td colspan="5" rowspan="1">Прочие расчеты</td>
</tr>
<tr>
<td> </td>
<td>Определение величины утраты товарной стоимости (без расчета стоимости ремонта)</td>
<td>3000</td>
<td>3650</td>
<td>6000</td>
<td>8000</td>
</tr>
<tr>
<td> </td>
<td>Определение рыночной стоимости транспортных средств</td>
<td>4300</td>
<td>5500</td>
<td>6000</td>
<td>7000</td>
</tr>
<tr>
<td> </td>
<td>Составление акта разногласий по калькуляциям (счетам) других организаций (по готовому расчету), экспертиза по нескольким актам осмотра</td>
<td>1500</td>
<td>2000</td>
<td colspan="2" rowspan="1">из расчета акта по наибольшему или совокупному количеству повреждений с коэффициентом 1,5</td>
</tr>
<tr>
<td> </td>
<td>Расчет стоимости годных остатков</td>
<td>3000</td>
<td>3500</td>
<td>от 6000</td>
<td>от 7000</td>
</tr>
</tbody>
</table># Оценка объектов интеллектуальной собственности [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-obektov-intellektualnoj-sobstvennosti/]
## 
Срок проведения работ: от 10 (десяти) рабочих дней
<table>
<tbody>
<tr>
<th><span>Вид</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка объектов интеллектуальной собственности</td>
<td>от 10 000 руб</td>
<td>от 10 000 руб</td>
<td> </td>
</tr>
</tbody>
</table># Экспертиза телефонов и планшетов [https://federallab.ru/uslugi-ekspertizyi/tovarnaya-ekspertiza/ekspertiza-telefonov-i-planshetov/]
## 
Ситуации, при которых мобильный телефон (смартфон) выходит из строя, еще находясь на гарантии, случаются все чаще. Быстрый выход новинок электроники на рынок, высокая конкуренция в этом сегменте и просто некачественный технологический процесс – это причины, по которым мобильный телефон ломается, прослужив несколько месяцев. Покупатель, зная, что у аппарата не закончился гарантийный срок использования, незамедлительно обращается к продавцу. Чаще всего компания без сложностей отправляет мобильный телефон на внутреннюю экспертизу (проверку качества).
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Экспертиза сотовых телефонов и электротехники, бытового оборудования и бытовой техники при стоимости товара</td>
<td>Минимальная стоимость досудебного исследования</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения</td>
</tr>
<tr>
<td style="text-align:right">3 000 – 5 000 руб. </td>
<td> 1 500 р.</td>
<td> 3 000</td>
<td colspan="1" rowspan="7"> 5 дней</td>
</tr>
<tr>
<td style="text-align:right">5 001 – 10 000 руб. </td>
<td> 2 000 р.</td>
<td> 4 000</td>
</tr>
<tr>
<td style="text-align:right">10 001 – 15 000 руб. </td>
<td> 3 000 р.</td>
<td> 6 000</td>
</tr>
<tr>
<td style="text-align:right">15 001 – 20 000 руб. </td>
<td> 3 500 р.</td>
<td> 7 000</td>
</tr>
<tr>
<td style="text-align:right">20 001 – 25 000 руб. </td>
<td> 4 000 р.</td>
<td> 8 000</td>
</tr>
<tr>
<td style="text-align:right">25 001 – 30 000 руб. </td>
<td> 5 000 р.</td>
<td> 10 000</td>
</tr>
<tr>
<td style="text-align:right">30 001 руб. и более </td>
<td> 6 000 р.</td>
<td> 12 000</td>
</tr>
</tbody>
</table># Оценка упущенной выгоды [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-upushhennoj-vyigodyi/]
## 
Срок проведения работ: от 7 (семи) рабочих дней
<table>
<tbody>
<tr>
<th><span>Вид экспертизы</span></th>
<th>Минимальная стоимость досудебного исследования, руб.</th>
<th>Стоимость судебной экспертизы, руб.</th>
<th>Минимальный срок проведения, дн</th>
</tr>
<tr>
<td colspan="4" style="text-align: center">Оценка рыночной стоимости транспортных средств</td>
</tr>
<tr>
<td>
			    легковые автомобили при количестве<br/><p></p><p></p>

                1 единица<br/>
                
                2-3 единицы<br/>
                
                4-5 единиц<br/>
                
                6-10 единиц<br/>
                
                10-30 единиц<br/><p></p>
                
                *расчет стоимости восстановительного ремонта при наличии повреждений не учтен
			</td>
<td>
			    4 300*<br/>

                3 500*<br/>
                
                3 000*<br/>
                
                2 750*<br/>
                
                2 500*
			</td>
<td>
			    6 000*<br/>

                5 000*<br/>
                
                4 000*<br/>
                
                3 500*<br/>
                
                3 000*
			</td>
<td style="text-align: center;">3-5</td>
</tr>
<tr>
<td>
			    грузовые, специальные автомобили при количестве:<br/><p></p><p></p>

                1 единица<br/>
                
                2-3 единицы<br/>
                
                4-5 единиц<br/>
                
                6-10 единиц<br/>
                
                10-30 единиц<br/><p></p>
                
                *расчет стоимости восстановительного ремонта при наличии повреждений не учтен
			</td>
<td>
			    5 500*<br/>

                5 000*<br/>
                
                4 500*<br/>
                
                4 000*<br/>
                
                3 500*
			</td>
<td>
			    7 000*<br/>

                6 000*<br/>
                
                5 250*<br/>
                
                4 750*<br/>
                
                4 250*
			</td>
<td style="text-align: center;">3-5</td>
</tr>
<tr>
<td>яхты, катера, лодки</td>
<td>7 000</td>
<td>10 000</td>
<td style="text-align: center;">5-7</td>
</tr>
<tr>
<td>прогулочные судна</td>
<td>15 000</td>
<td>20 000</td>
<td style="text-align: center;">10-15</td>
</tr>
</tbody>
</table># Экспертиза бытовой техники [https://federallab.ru/uslugi-ekspertizyi/tovarnaya-ekspertiza/ekspertiza-byitovoj-texniki/]
## 
Стоимость и сроки
 
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Экспертиза бытового оборудования и бытовой техники при стоимости товара</td>
<td>Минимальная стоимость досудебного исследования, руб.</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения</td>
</tr>
<tr>
<td style="text-align:right">3 000 – 5 000 руб.</td>
<td>1 500</td>
<td>3 000</td>
<td colspan="1" rowspan="7">5 дней</td>
</tr>
<tr>
<td style="text-align:right">5 001 – 10 000 руб.</td>
<td>2 000</td>
<td>4 000</td>
</tr>
<tr>
<td style="text-align:right">10 001 - 15 000 руб.</td>
<td>3 000</td>
<td>6 000</td>
</tr>
<tr>
<td style="text-align:right">15 001 - 20 000 руб.</td>
<td>3 500</td>
<td>7 000</td>
</tr>
<tr>
<td style="text-align:right">20 001 - 25 000 руб.</td>
<td>4 000</td>
<td>8 000</td>
</tr>
<tr>
<td style="text-align:right">25 001 – 30 000 руб.</td>
<td>5 000</td>
<td>10 000</td>
</tr>
<tr>
<td style="text-align:right">30 001 руб. и более</td>
<td>6 000</td>
<td>12 000</td>
</tr>
</tbody>
</table># Судебная экспертиза документов [https://federallab.ru/uslugi-ekspertizyi/sudebnaya-ekspertiza-dokumentov/]
## 
# Судебная экспертиза документов [https://federallab.ru/uslugi-ekspertizyi/sudebnaya-ekspertiza-dokumentov/]
<table>
<tbody>
<tr>
<th><span>Независимая экспертиза</span></th>
<th>Минимальные тарифы</th>
</tr>
<tr>
<td>Экспертиза подписи</td>
<td>8 000 руб.</td>
</tr>
<tr>
<td>Экспертиза печати</td>
<td>10 000 руб.</td>
</tr>
<tr>
<td>Экспертиза рукописного текста</td>
<td>10 000 руб.</td>
</tr>
</tbody>
</table># Почерковедческая экспертиза [https://federallab.ru/uslugi-ekspertizyi/podcherkovedcheskaya-ekspertiza/]
## 
Стоимость и сроки
<table>
<tbody>
<tr>
<th><span>Почерковедческая экспертиза</span></th>
<th>Срок</th>
<th>Цена</th>
</tr>
<tr>
<td>Экспертиза 1 подписи</td>
<td>5</td>
<td>10 000р.</td>
</tr>
<tr>
<td>Экспертиза 1 и более подписей</td>
<td>5-10</td>
<td>8 000 руб. и 4 000 руб. за каждую следующую подпись одного лица</td>
</tr>
<tr>
<td>Экспертиза 1 подписи и расшифровки фамилии, имени и отчества</td>
<td>5</td>
<td>от 15 000р.</td>
</tr>
<tr>
<td>Экспертиза 1 и более подписи и расшифровки фамилии, имени и отчества</td>
<td>5-15</td>
<td>15 000 руб. и 4 500 руб. за каждую следующую подпись и расшифровку одного лица</td>
</tr>
<tr>
<td>Консультации при назначении технической экспертизы документов</td>
<td>1</td>
<td>от 3 000</td>
</tr>
</tbody>
</table># Бухгалтерская экспертиза [https://federallab.ru/uslugi-ekspertizyi/buxgalterskaya-ekspertiza/]
## 
Сроки проведения бухгалтерской экспертизы
<table>
<tbody>
<tr>
<th><span>Бухгалтерская экспертиза</span></th>
<th>Срок</th>
<th>Цена</th>
</tr>
<tr>
<td>Экспертиза бухгалтерской (финансовой отчетности)</td>
<td>7-15</td>
<td>от 15 000 руб.</td>
</tr>
<tr>
<td>Экспертиза первичных документов</td>
<td>7-15</td>
<td>от 15 000 руб.</td>
</tr>
<tr>
<td>Анализ финансово-хозяйственной деятельности</td>
<td>10-20</td>
<td>от 30 000 руб.</td>
</tr>
<tr>
<td>Экспертиза преднамеренности и фиктивности банкротств</td>
<td>20-30</td>
<td>от 20 000 руб.</td>
</tr>
<tr>
<td>Экспертиза правильности расчетов по кредитным договорам</td>
<td>10</td>
<td>От 15 000 руб.</td>
</tr>
</tbody>
</table># Оценка машин и оборудования [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-mashin-i-oborudovaniya/]
## 
Срок проведения работ: от 2 (двух) рабочих дней
<table>
<tbody>
<tr>
<th><span>Вид экспертизы</span></th>
<th>Минимальная стоимость досудебного исследования, руб.</th>
<th>Стоимость судебной экспертизы, руб.</th>
<th>Минимальный срок проведения, дн</th>
</tr>
<tr>
<td>Оценка рыночной стоимости специального оборудования, станков с ЧПУ, специальной техники</td>
<td>с коэффициентом 2 от цен за оценку серийного оборудования</td>
<td> </td>
<td> </td>
</tr>
<tr>
<td>Оценка рыночной стоимости технологической линии в зависимости от количества узлов и агрегатов</td>
<td>От 15 000</td>
<td>20 000</td>
<td> </td>
</tr>
<tr>
<td>Оценка бизнеса, акций, долей в уставном капитале</td>
<td>От 15 000</td>
<td>24 000</td>
<td>15-30</td>
</tr>
<tr>
<td>Оценка акций, котируемых на ОРЦБ</td>
<td>2 000</td>
<td>5 000</td>
<td>5-10</td>
</tr>
<tr>
<td>Оценка дебиторской задолженности</td>
<td>От 15 000</td>
<td>24 000</td>
<td>5-10</td>
</tr>
</tbody>
</table># Оценка автотранспорта [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-avtotransporta/]
## 
Связаться с нами возможно в двух форматах: позвонить по номеру, указанному в шапке сайта, или заполнить форму обращения ниже, чтобы наш оператор перезвонил в ближайшее время. График работы: с понедельника по пятницу с 9:00 до 18:00 без перерывов.
<table>
<tbody>
<tr>
<th><span>Вид экспертизы</span></th>
<th>Минимальная стоимость досудебного исследования, руб.</th>
<th>Стоимость судебной экспертизы, руб.</th>
<th>Минимальный срок проведения, дн</th>
</tr>
<tr>
<td colspan="4" style="text-align: center">Оценка рыночной стоимости транспортных средств</td>
</tr>
<tr>
<td>
			    легковые автомобили при количестве<br/><p></p><p></p>

                1 единица<br/>
                
                2-3 единицы<br/>
                
                4-5 единиц<br/>
                
                6-10 единиц<br/>
                
                10-30 единиц<br/><p></p>
                
                *расчет стоимости восстановительного ремонта при наличии повреждений не учтен
			</td>
<td>
			    4 300*<br/>

                3 500*<br/>
                
                3 000*<br/>
                
                2 750*<br/>
                
                2 500*
			</td>
<td>
			    6 000*<br/>

                5 000*<br/>
                
                4 000*<br/>
                
                3 500*<br/>
                
                3 000*
			</td>
<td style="text-align: center;">3-5</td>
</tr>
<tr>
<td>
			    грузовые, специальные автомобили при количестве:<br/><p></p><p></p>

                1 единица<br/>
                
                2-3 единицы<br/>
                
                4-5 единиц<br/>
                
                6-10 единиц<br/>
                
                10-30 единиц<br/><p></p>
                
                *расчет стоимости восстановительного ремонта при наличии повреждений не учтен
			</td>
<td>
			    5 500*<br/>

                5 000*<br/>
                
                4 500*<br/>
                
                4 000*<br/>
                
                3 500*
			</td>
<td>
			    7 000*<br/>

                6 000*<br/>
                
                5 250*<br/>
                
                4 750*<br/>
                
                4 250*
			</td>
<td style="text-align: center;">3-5</td>
</tr>
<tr>
<td>яхты, катера, лодки</td>
<td>7 000</td>
<td>10 000</td>
<td style="text-align: center;">5-7</td>
</tr>
<tr>
<td>прогулочные судна</td>
<td>15 000</td>
<td>20 000</td>
<td style="text-align: center;">10-15</td>
</tr>
</tbody>
</table># Налоговая экспертиза [https://federallab.ru/uslugi-ekspertizyi/nalogovaya-ekspertiza/]
## 
# Налоговая экспертиза [https://federallab.ru/uslugi-ekspertizyi/nalogovaya-ekspertiza/]
<table>
<tbody>
<tr>
<th><span>Услуга</span></th>
<th>Срок, дн.</th>
<th>Цена</th>
</tr>
<tr>
<td>Независимая налоговая экспертиза</td>
<td>5-10</td>
<td>от 24 000 руб.</td>
</tr>
</tbody>
</table># Техническое обследование зданий и сооружений [https://federallab.ru/uslugi-ekspertizyi/stroitelno-texnicheskaya-ekspertiza/texnicheskoe-obsledovanie-zdanij-i-sooruzhenij/]
## 
Решение вышеуказанных вопросов немыслимо без проведения технических экспертиз и заключений профессионалов. Также осуществляется обследование зданий и сооружений, что является одним из эффективнейших способов определения высокого качества проведенных работ в соответствии с нормативными документами и установленными стандартами.
<table>
<tbody>
<tr>
<th><span>Строительно-техническая экспертиза</span></th>
<th>Срок</th>
<th>Цена</th>
</tr>
<tr>
<td>Экспертиза по определению объема фактически выполненных строительно-монтажных работ</td>
<td>5-15 дней</td>
<td>от 15 000 руб.</td>
</tr>
<tr>
<td>Экспертиза соответствия расположения строений на участке требованиям нормативных документов</td>
<td>5-10 дней</td>
<td>от 20 000 руб.</td>
</tr>
</tbody>
</table>