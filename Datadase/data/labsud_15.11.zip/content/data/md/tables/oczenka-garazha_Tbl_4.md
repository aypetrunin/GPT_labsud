# Оценка гаража [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-garazha/]
## 
Срок проведения работ: от 3 (трех) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза нежилых помещений</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Индивидуальные гаражи</td>
<td>6 000 руб.</td>
<td>10 000 руб.</td>
<td></td>
</tr>
</tbody>
</table>