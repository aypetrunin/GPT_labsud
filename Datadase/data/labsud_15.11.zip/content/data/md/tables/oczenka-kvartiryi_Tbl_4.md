# Оценка квартиры [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-kvartiryi/]
## 
Срок проведения работ: от 2 (двух) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка квартир</td>
<td>3 000 руб.</td>
<td>6 000 руб.</td>
<td>3 дней</td>
</tr>
</tbody>
</table>