# Экспертиза бытовой техники [https://federallab.ru/uslugi-ekspertizyi/tovarnaya-ekspertiza/ekspertiza-byitovoj-texniki/]
## 
## Стоимость и сроки
 
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td>Экспертиза бытового оборудования и бытовой техники при стоимости товара</td>
<td>Минимальная стоимость досудебного исследования, руб.</td>
<td>Стоимость судебной экспертизы, руб.</td>
<td>Минимальный срок проведения</td>
</tr>
<tr>
<td style="text-align:right">3 000 – 5 000 руб.</td>
<td>1 500</td>
<td>3 000</td>
<td colspan="1" rowspan="7">5 дней</td>
</tr>
<tr>
<td style="text-align:right">5 001 – 10 000 руб.</td>
<td>2 000</td>
<td>4 000</td>
</tr>
<tr>
<td style="text-align:right">10 001 - 15 000 руб.</td>
<td>3 000</td>
<td>6 000</td>
</tr>
<tr>
<td style="text-align:right">15 001 - 20 000 руб.</td>
<td>3 500</td>
<td>7 000</td>
</tr>
<tr>
<td style="text-align:right">20 001 - 25 000 руб.</td>
<td>4 000</td>
<td>8 000</td>
</tr>
<tr>
<td style="text-align:right">25 001 – 30 000 руб.</td>
<td>5 000</td>
<td>10 000</td>
</tr>
<tr>
<td style="text-align:right">30 001 руб. и более</td>
<td>6 000</td>
<td>12 000</td>
</tr>
</tbody>
</table>