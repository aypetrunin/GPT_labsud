# Оценка дачи [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-dachi/]
## 
Срок проведения работ: от 3 (трех) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td height="14" valign="bottom" width="364">
<p class="western"><span style="font-size: small;">Оценка земельных участков</span></p>
</td>
<td valign="bottom" width="118">
<p class="western"> </p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"> </p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">некоммерческого назначения площадью до 30 сот.</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">6 000</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">10 000</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">3-5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">некоммерческого назначения площадью от 31 сот. до 1 га</span></p>
</td>
<td width="118">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">15 000</span></span></span></p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">с коэффициентом 1,2</span></span></span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">коммерческого назначения </span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">от 20 000</span></p>
</td>
<td width="136">
<p align="center" class="western" lang="en-US"><span style="color: #000000;"><span style="font-size: small;"><span lang="ru-RU">с коэффициентом 1,2</span></span></span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">5</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">сельскохозяйственного назначения</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">20 000</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">10</span></p>
</td>
</tr>
<tr valign="bottom">
<td width="364">
<p class="western"><span style="font-size: small;">Ретроспективная оценка объектов (на дату в прошлом)</span></p>
</td>
<td width="118">
<p align="center" class="western"><span style="font-size: small;">+ 20% к тарифу</span></p>
</td>
<td width="136">
<p align="center" class="western"><span style="font-size: small;">1,2</span></p>
</td>
<td width="62">
<p align="center" class="western"><span style="font-size: small;">+ 3</span></p>
</td>
</tr>
<tr>
</tr></tbody>
</table>