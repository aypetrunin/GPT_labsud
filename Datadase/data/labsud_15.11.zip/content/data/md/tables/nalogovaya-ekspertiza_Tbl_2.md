# Налоговая экспертиза [https://federallab.ru/uslugi-ekspertizyi/nalogovaya-ekspertiza/]
## 

<table>
<tbody>
<tr>
<th><span>Услуга</span></th>
<th>Срок, дн.</th>
<th>Цена</th>
</tr>
<tr>
<td>Независимая налоговая экспертиза</td>
<td>5-10</td>
<td>от 24 000 руб.</td>
</tr>
</tbody>
</table>