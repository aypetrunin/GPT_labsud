# Судебная экспертиза документов [https://federallab.ru/uslugi-ekspertizyi/sudebnaya-ekspertiza-dokumentov/]
## 

<table>
<tbody>
<tr>
<th><span>Независимая экспертиза</span></th>
<th>Минимальные тарифы</th>
</tr>
<tr>
<td>Экспертиза подписи</td>
<td>8 000 руб.</td>
</tr>
<tr>
<td>Экспертиза печати</td>
<td>10 000 руб.</td>
</tr>
<tr>
<td>Экспертиза рукописного текста</td>
<td>10 000 руб.</td>
</tr>
</tbody>
</table>