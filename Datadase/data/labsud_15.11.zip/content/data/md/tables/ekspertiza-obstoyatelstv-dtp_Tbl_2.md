# Экспертиза обстоятельств ДТП [https://federallab.ru/uslugi-ekspertizyi/avtotexnicheskaya-ekspertiza/ekspertiza-obstoyatelstv-dtp/]
## 
Экспертизы от нашей компании полностью соответствуют нормативно-правовым актам и признаются в судах. Работаем по всей стране для того чтобы каждый человек смог получить экспертные услуги на качественном уровне и в срок.
<table border="1" cellpadding="0" cellspacing="0" class="price-list">
<tbody>
<tr class="table-header_blue">
<td colspan="6" style="width: 68%;" valign="top">
<p class="western"><span style="font-size: small;"><strong>Составления акта осмотра (повреждений)</strong></span></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">Составление акта осмотра (повреждений) не более 1 позиции</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">1050</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">1200</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2100</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2400</span></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">Составление акта осмотра (повреждений) с включением от 2 до 3 позиций</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">1150</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">1350</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2300</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2700</span></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">То же, с включением от 4 до 5 позиций</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">1350</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">1450</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2700</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2900</span></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">То же, с включением от 6 до 10 позиций</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">1550</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2000</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">3100</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">4000</span></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">То же, с включением от 11 до 20 позиций</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">1750</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2300</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">3500</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">4600</span></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">То же, с включением от 21 до 30 позиций</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2000</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2550</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">4000</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">5100</span></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">То же, с включением от 31 до 40 позиций</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2300</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">3100</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">4600</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">6200</span></p>
</td>
</tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">То же, с включением от 41 до 50 позиций</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">2750</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">3400</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">5500</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">6800</span></p>
</td>
<tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">То же, с включением от 51 до 60 позиций</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">3000</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">3900</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">6000</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">7800</span></p>
</td>
</tr>
<tr>
<td style="width: 36%;" valign="top">
<p class="western"><span style="font-size: small;">То же, с включением от 61 позиции и более</span></p>
</td>
<td style="width: 17.1707%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">3500</span></p>
</td>
<td style="width: 14.8293%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">4650</span></p>
</td>
<td style="width: 21%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">7000</span></p>
</td>
<td colspan="2" style="width: 65%;" valign="bottom">
<p align="center" class="western"><span style="font-size: small;">9300</span></p>
</td>
</tr>
</tbody>
</table>