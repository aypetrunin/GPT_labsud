# Оценка бизнеса [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-biznesa/]
## 
Срок проведения работ: от 7 (семи) рабочих дней
<table>
<tbody>
<tr>
<th><span>Оценочная экспертиза</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка бизнеса, акций, долей в уставном капитале</td>
<td>от 15 000 руб.</td>
<td>24 000 руб.</td>
<td>15-30 дней</td>
</tr>
</tbody>
</table>