# Экспертиза проектов [https://federallab.ru/uslugi-ekspertizyi/ekspertiza-proektov/]
## 
Предоставляем предварительный анализ целесообразности такой работы для клиента, по ключевым замечаниям.
<table>
<tbody>
<tr>
<th><span>Экспертиза проектной документации</span></th>
<th>Цена</th>
</tr>
<tr>
<td>Экспертиза проектов</td>
<td>от 60 000 руб.</td>
</tr>
</tbody>
</table>