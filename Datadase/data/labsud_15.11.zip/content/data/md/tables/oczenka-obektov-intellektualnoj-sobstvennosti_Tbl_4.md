# Оценка объектов интеллектуальной собственности [https://federallab.ru/uslugi-ekspertizyi/oczenochnaya-ekspertiza/oczenka-obektov-intellektualnoj-sobstvennosti/]
## 
Срок проведения работ: от 10 (десяти) рабочих дней
<table>
<tbody>
<tr>
<th><span>Вид</span></th>
<th>Стоимость досудебного исследования</th>
<th>Стоимость судебной экспертизы</th>
<th>Сроки</th>
</tr>
<tr>
<td>Оценка объектов интеллектуальной собственности</td>
<td>от 10 000 руб</td>
<td>от 10 000 руб</td>
<td> </td>
</tr>
</tbody>
</table>